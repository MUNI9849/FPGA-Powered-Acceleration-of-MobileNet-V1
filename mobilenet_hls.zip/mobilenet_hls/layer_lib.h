#ifndef __LAYER_LIB_H__
#define __LAYER_LIB_H__

#define input_R 224
#define input_C 224
#define input_channel 3
#define output_length 64


#define CONV_K1 3
#define CONV_K2 3
#define CONV_K3 1


#define CONV1_Rin 224
#define CONV1_Cin 224
#define CONV1_R 112
#define CONV1_C 112
#define CONV1_CHin 3
#define CONV1_CHout 32

#define CONV1d_Rin 112
#define CONV1d_Cin 112
#define CONV1d_R 112
#define CONV1d_C 112
#define CONV1d_CHin 32
#define CONV1d_CHout 32

#define CONV1p_R 112
#define CONV1p_C 112
#define CONV1p_CHin 32
#define CONV1p_CHout 64


#endif
