#include<stdio.h>
#include "layer_lib.h"
#include "batchnormalization.h"
#include <hls_stream.h>

void  mobilenet(
    float *conv1_w,
    float *conv1_dw,
    float *conv1_pw,
    float *input_data,
    float *output_data
)

{

#pragma HLS INTERFACE m_axi depth=256 port=input_data offset=slave bundle=input
#pragma HLS INTERFACE s_axilite port=input_data

#pragma HLS INTERFACE m_axi depth=256 port=conv1_w offset=slave bundle=conv1
#pragma HLS INTERFACE s_axilite port=conv1_w

#pragma HLS INTERFACE m_axi depth=256 port=conv1_dw offset=slave bundle=conv1d
#pragma HLS INTERFACE s_axilite port=conv1_dw

#pragma HLS INTERFACE m_axi depth=256 port=conv1_pw offset=slave bundle=conv1p
#pragma HLS INTERFACE s_axilite port=conv1_pw

#pragma HLS INTERFACE m_axi depth=256 port=output_data offset=slave bundle=output
#pragma HLS INTERFACE s_axilite port=output_data


//#pragma HLS INTERFACE s_axilite port=return bundle=LeNet
//            REGISTER DEFINITION			//


    static float input_data_buf[input_channel][input_R][input_C];
//#pragma HLS ARRAY_PARTITION variable=input_data_buf complete dim=1

// input_channel = 3 , input_R=224, input_C=224

    static float conv1_out[CONV1_CHout][CONV1_R][CONV1_C];
#pragma HLS ARRAY_PARTITION variable=conv1_out cyclic factor=8 dim=1

// CONV1_CHout = 3, CONV1_R=226 CONV1_C32=226

    static float conv1d_out[32][CONV1d_R][CONV1d_C];
#pragma HLS ARRAY_PARTITION variable=conv1d_out cyclic factor=8 dim=1

//CONV1_DWCHout = 32, CONV1DW_R=112, CONV1DW_C]=122

    static float conv1p_out[CONV1p_CHout][CONV1p_R][CONV1p_C];
#pragma HLS ARRAY_PARTITION variable=conv1p_out cyclic factor=8 dim=1
//CONV1PW_CHout = 32, CCONV1PW_R=112, CONV1PW_C=112
    static float output_data_buf[output_length];
    // output_length = 112
    static float conv1_W_buf[CONV1_CHout][CONV1_CHin][CONV_K1][CONV_K1];
#pragma HLS ARRAY_PARTITION variable=conv1_W_buf complete dim=2
#pragma HLS ARRAY_PARTITION variable=conv1_W_buf cyclic factor=8 dim=1

    static float conv1_dW_buf[CONV1d_CHout][CONV_K2][CONV_K2];
#pragma HLS ARRAY_PARTITION variable=conv1_dW_buf cyclic factor=8 dim=1

    float conv1_pW_buf[CONV1p_CHout][CONV1p_CHin];
#pragma HLS ARRAY_PARTITION variable=conv1_pW_buf cyclic factor=8 dim=1


    				//			 LOAD SOME WEIGHTS			 //

Label1: for (int m = 0; m < CONV_K1; m++)
		{

	Label2: for (int n = 0; n < CONV_K1; n++)
			{

			Label3:	for (int j = 0; j < CONV1_CHin; j++)
					{

					Label4:for (int i = 0; i < CONV1_CHout; i++)
							{
#pragma HLS UNROLL factor=8

							conv1_W_buf[i][j][m][n] = *conv1_w++;
							//printf("%f \n",conv1_W_buf[i][j][m][n]);
							}

					}

			}
		}

Label5: for (int i = 0; i < input_R; i++)
    	{

		Label6: for (int j = 0; j < input_C; j++)
				{

				Label7:	for (int chi = 0; chi < input_channel; chi++)
						{
#pragma HLS UNROLL factor=3

						input_data_buf[chi][i][j] = *input_data++;


						}
				}
    	}
			// 				CONV1_LAYER				//
Label8: for (int i = 0; i < 32; i++)
		{

		Label9:	for (int j = 0; j < 112; j++)
				{

				Label10: for (int m = 0; m < 112; m++)
						{

						conv1_out[i][j][m] = 0;

						}

				}

			}

Label11: for(int kr=0; kr<CONV_K1; kr++)
		 {
		 Label12: for(int kc=0; kc<CONV_K1; kc++)
				  {
				  Label13: for(int r=0; r<CONV1_R; r++)
				  	  	   {

					  	  	 CONV1_PIPE:for(int c=0; c<CONV1_C; c++)
					  	  	 {
//#pragma HLS PIPELINE

					  	  		 Label14: for(int cho=0; cho<CONV1_CHout; cho++)
					  	  		 {
								 #pragma HLS UNROLL factor=8
					  	  		Label15:for(int chi=0; chi<CONV1_CHin; chi++)
					  	  				{
					  	  				conv1_out[cho][r][c] += input_data_buf[chi][r+kr][c+kc] * conv1_W_buf[cho][chi][kr][kc];


					  	  				}
					  	  		 }
					  	  	 }
				  	  	   }
				  }
		 }






				//			batch norm CONV1_LAYER			//


	    static float output1[CONV1_CHout][CONV1_R][CONV1_C];
	    batchnormalization(conv1_out,output1);




	    			//			reLu CONV1_LAYER			//


Label16: for (int i = 0; i < CONV1_CHout; i++)
		 {

		 Label17:for (int j = 0; j < CONV1_R; j++)
				{

			 	 Label18:for (int m = 0; m < CONV1_C; m++)
			 	 	 	 {

			 		 	 conv1_out[i][j][m] = (output1[i][j][m]>0) ? output1[i][j][m] : 0;
			 	 	 	 }

				}

		 }

//practce starts


    for (int m = 0; m < 3; m++) {
        for (int n = 0; n < 3; n++) {
        	for (int cho = 0; cho < 32; cho++) {
                conv1_dW_buf[cho][m][n] = *conv1_dw++;
                   	//printf("%f\n",conv1_dW_buf[cho][m][n]);
        }
    }
}

for (int chi = 0; chi < 32; chi++) {
    for (int r = 0; r < 112; r++) {
      for (int c = 0; c < 112; c++) {
    	  conv1d_out[chi][r][c] = 0;
      }
    }
  }


static float input1d[32][114][114];
for(int chi = 0; chi < 32; chi++) {
    for(int r = 0; r < 114; r++) {
        for(int c = 0; c < 114; c++) {
            if ((r > 0 && r < 113) && (c > 0 && c < 113)) {
                input1d[chi][r][c] = conv1_out[chi][r - 1][c - 1];

            }
            else {
                input1d[chi][r][c] = 0;
            }
        }
    }
}



for(int x=2;x<3;x++)
{
	for(int y=0;y<3;y++)
	{
		for(int z=0;z<3;z++)
		{
			printf("%f \t",conv1_dW_buf[x][y][z]);
		}
		printf("\n");
	}
	printf("\n");
}

for (int k = 0; k < 32; k++) {
	for (int i = 0; i < 112; i++) {
      for (int j = 0; j < 112; j++) {
          for (int r = 0; r < 3; r++) {
            for (int s = 0; s < 3; s++) {
            	conv1d_out[k][i][j] = conv1d_out[k][i][j] + input1d[k][i + r][j + s] * conv1_dW_buf[k][r][s];
            }
          }
     }
   }
 }
 

 
 
//printf("%f\n",conv1d_out[3][0][0]);
          			for(int cho=0;cho<10;cho++)
          	      	{
          	    	//	printf("%f\n",conv1d_out[cho][0][0]);
          	      	}


}
