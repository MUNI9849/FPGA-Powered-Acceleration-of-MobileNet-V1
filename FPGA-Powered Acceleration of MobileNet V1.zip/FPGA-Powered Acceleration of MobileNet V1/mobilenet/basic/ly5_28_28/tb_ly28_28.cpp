#include <stdio.h>
#include <math.h>

void  mobilenet(
    float *conv5d_w,
    float *conv5p_w,
	float *input_data,
    float *output_data
);

int  main()

{

#include "D:\Term_Paper\ly28_28\conv5d_weight.txt"
#include "D:\Term_Paper\ly28_28\conv5p_weight.txt"

#include "D:\Term_Paper\ly28_28\conv5d_inp.txt"


static float InputData[30*30*256];
static float OutputData[28*28*256];

static float conv5d_w1[256*3*3];
static float conv5p_w1[256*256];
static float output_buf5[256][28][28];

int count=0;
int cnt = 0;
int cnt1=0;
	
static float input5d[256][30][30];
for(int chi = 0; chi < 256; chi++) {
	for(int r = 0; r < 30; r++) {
		for(int c = 0; c < 30; c++) {
			if ((r > 0 && r < 29) && (c > 0 && c < 29)) {
				input5d[chi][r][c] = conv5d_inp[r - 1][c - 1][chi];
					
			}
			else {
				input5d[chi][r][c] = 0;
			}
		}
	}
}

	count=0;
	for(int ch=0;ch<256;ch++)
	{
		for(int r=0;r<30;r++)
		{
			for(int c=0;c<30;c++)
			{
				InputData[count] = input5d[ch][r][c];
				count++;
			}
		}
	}

	cnt=0;
	for(int ch=0;ch<256;ch++)
	{
		for(int r=0;r<3;r++)
		{
			for(int c=0;c<3;c++)
			{
				conv5d_w1[cnt] = conv5d_w[r][c][ch];
				cnt++;
			}
		}
	}

	cnt1=0;
	for(int ch=0;ch<256;ch++)
	{
		for(int ci=0;ci<256;ci++)
		{
			for(int r=0;r<1;r++)
			{
				for(int c=0;c<1;c++)
				{
					conv5p_w1[cnt1] = conv5p_w[r][c][ci][ch];
					cnt1++;
				}
			}
		}
	}


	mobilenet(conv5d_w1, conv5p_w1, InputData,OutputData);
	
	int cnt2 = 0;
	for(int ch=0;ch<256;ch++)
	{
		for(int r=0;r<30;r++)
		{
			for(int c=0;c<30;c++)
			{
				//printf("%d \t", &InputData[cnt2]);
				cnt2++;
			}
			//printf("\n");
		}
		//printf("\n");
	}
	//printf("\n");


	int cnt3=0;
	for(int ch=0;ch<256;ch++)
	{
		for(int r=0;r<3;r++)
		{
			for(int c=0;c<3;c++)
			{
				//printf("%d \t", &conv5d_w1[cnt3]);
				cnt3++;
			}
			//printf("\n");
		}
		//printf("\n");
	}
	//printf("\n");


	int cnt4=0;
	for(int ch=0;ch<256;ch++)
	{
		for(int c=0;c<256;c++)
		{
			//printf("%d \t",&conv5p_w1[cnt4]);
			cnt4++;
		}
		//printf("\n");
	}
	//printf("\n");


	int cnt5 = 0;
	for(int ch=0;ch<256;ch++)
	{
		for(int r=0;r<28;r++)
		{
			for(int c=0;c<28;c++)
			{
				//printf("%d \t", &OutputData[cnt5]);
				cnt5++;
			}
			//printf("\n");
		}
		//printf("\n");
	}
	//printf("\n");


	int cnt6 = 0;
	for(int ch=0;ch<1;ch++)
	{
		for(int r=0;r<28;r++)
		{
			for(int c=0;c<28;c++)
			{
				//printf("%f \t", OutputData[cnt6]);
				cnt6++;
			}
			//printf("\n");
		}
		//printf("\n");
	}
	//printf("\n");

return 0;

}
