#include<stdio.h>
#include "math.h"

void fun_dw1(float inp[9][9] , float cvw[3][3], float out[7][7])
{
    label1:for (int j = 0; j < 7; j++) {
    	label2:for (int m = 0; m < 7; m++) {
    		label3:for (int x = 0; x < 3; x++) {
    			label4:for (int y = 0; y < 3; y++) {
                	out[j][m] += inp[j + x][m + y] * cvw[x][y];
                }
            }
        }
    }
}

void fun_bn1(float (*inp1)[7][7], int length, float *bgammax, float *bbetax, float *bmeanx, float *bvarx, float (*out1)[7][7])
{
	label5:for(int cho=0;cho<length;cho++){
		label6:for(int r=0;r<7;r++){
			label7:for(int c=0;c<7;c++){
				float normalized_value = (inp1[cho][r][c] - bmeanx[cho]) / sqrt(bvarx[cho]+1e-3);
				float scaled_value = bgammax[cho] * normalized_value + bbetax[cho];
				if(scaled_value < 0.0)
				{
					out1[cho][r][c]= 0.0;
				}
				else if(scaled_value > 6.0)
				{
					out1[cho][r][c]= 6.0;
				}
				else
				{
					out1[cho][r][c]=scaled_value;
				}
			}
		}
	}

}

void fun_pw1(float (*inp2)[7][7], int length, float (*cvw2), float (*out2)[7][7], int length0)
{
    label8: for (int r = 0; r < 7; r++) {
        label9: for (int c = 0; c < 7; c++) {
            label10: for (int cho = 0; cho < length0; cho++) {
                label11: for (int chi = 0; chi < length; chi++) {
                    out2[cho][r][c] += inp2[chi][r][c] * cvw2[cho * length + chi];
                }
            }
        }
    }
}

void fun_bn2(float (*inp1)[7][7], int length, float (*inp2)[7][7], float (*bgammax), float (*bbetax), float (*bmeanx), float (*bvarx), float (*out)[7][7],  int length0)
{

	label12:for(int cho=0;cho<length0;cho++){
		float scaled_value;
		label3:for(int r=0;r<7;r++){
			label14:for(int c=0;c<7;c++){
				if(cho < length){
					float normalized_value = (inp1[cho][r][c] - bmeanx[cho]) / sqrt(bvarx[cho]+1e-3);
					scaled_value = bgammax[cho] * normalized_value + bbetax[cho];
				}
				else{
					float normalized_value = (inp2[cho-32][r][c] - bmeanx[cho]) / sqrt(bvarx[cho]+1e-3);
					scaled_value = bgammax[cho] * normalized_value + bbetax[cho];
				}
				if(scaled_value < 0.0)
				{
					out[cho][r][c]= 0.0;
				}
				else if(scaled_value > 6.0)
				{
					out[cho][r][c]= 6.0;
				}
				else
				{
					out[cho][r][c]=scaled_value;
				}
			}
		}
	}
}

void  mobilenet(
    float *conv9_dw,
    float *conv9_pw,
	float *input_data,
    float *output_data
)

{
#pragma HLS INTERFACE m_axi depth=1024 port=conv9_dw offset=slave bundle=conv9d
#pragma HLS INTERFACE s_axilite port=conv9_dw

#pragma HLS INTERFACE m_axi depth=1024 port=conv9_pw offset=slave bundle=conv9p
#pragma HLS INTERFACE s_axilite port=conv9_pw

#pragma HLS INTERFACE m_axi depth=1024 port=input_data offset=slave bundle=input
#pragma HLS INTERFACE s_axilite port=input_data

#pragma HLS INTERFACE m_axi depth=1024 port=output_data offset=slave bundle=output
#pragma HLS INTERFACE s_axilite port=output_data
#pragma HLS INTERFACE s_axilite port=return

#include "D:\Term_Paper\ly9_7_7\conv9d_1.txt"
#include "D:\Term_Paper\ly9_7_7\conv9d_2.txt"
#include "D:\Term_Paper\ly9_7_7\conv9d_3.txt"
#include "D:\Term_Paper\ly9_7_7\conv9d_4.txt"

#pragma HLS array_partition variable=gamma complete dim=0
#pragma HLS array_partition variable=beta complete dim=0
#pragma HLS array_partition variable=batch_mean complete dim=0
#pragma HLS array_partition variable=batch_variance complete dim=0

#include "D:\Term_Paper\ly9_7_7\conv9p_1.txt"
#include "D:\Term_Paper\ly9_7_7\conv9p_2.txt"
#include "D:\Term_Paper\ly9_7_7\conv9p_3.txt"
#include "D:\Term_Paper\ly9_7_7\conv9p_4.txt"

#pragma HLS array_partition variable=gamma1 complete dim=0
#pragma HLS array_partition variable=beta1 complete dim=0
#pragma HLS array_partition variable=batch_mean1 complete dim=0
#pragma HLS array_partition variable=batch_variance1 complete dim=0

    float d1planar1x1[1024][9][9];
	#pragma HLS array_partition variable=d1planar1x1 cyclic factor=32 dim=1
    float xbufferw1[1024][3][3];
	#pragma HLS array_partition variable=xbufferw1 cyclic factor=32 dim=1
    float dw_out_buff[1024][7][7];
	#pragma HLS array_partition variable=dw_out_buff cyclic factor=32 dim=1
    float dw_bn_out[1024][7][7];
	#pragma HLS array_partition variable=dw_bn_out cyclic factor=32 dim=1
    static float pw_w_buf1[512][1024];
	#pragma HLS array_partition variable=pw_w_buf1 cyclic factor=32 dim=2
	#pragma HLS array_partition variable=pw_w_buf1 cyclic factor=16 dim=1
    static float pw_w_buf2[512][1024];
	#pragma HLS array_partition variable=pw_w_buf2 cyclic factor=32 dim=2
	#pragma HLS array_partition variable=pw_w_buf2 cyclic factor=16 dim=1
	static float pw_out_buf1[512][7][7];
	#pragma HLS array_partition variable=pw_out_buf1 cyclic factor=16 dim=1
    static float pw_out_buf2[512][7][7];
	#pragma HLS array_partition variable=pw_out_buf2 cyclic factor=16 dim=1
	static float out_bn2_buf1[512][7][7];
	#pragma HLS array_partition variable=out_bn2_buf1 cyclic factor=8 dim=1
	static float out_bn2_buf2[512][7][7];
	#pragma HLS array_partition variable=out_bn2_buf2 cyclic factor=8 dim=1

    int OFFCHIP_WIDTH=9;
    int OFFCHIP_WIDTH1=7;
    int kchin1=0;
    int kchin2=0;
    int chwp = 0;

    label15:for(int tileIndex=0;tileIndex<1;tileIndex++)  // only 1 as size of each image is 30x30 only
     {
		chwp = 0;
		int startRow = (tileIndex / 1) * (9 - 2);
		int startCol = (tileIndex % 1) * (9 - 2);
		int k=0;
		label16:for (int ch = 0; ch < 1024; ch++)
		{
			label17:for (int i = 0; i < 9; i++)
			{
				label18:for (int j = 0; j < 9; j++)
				{
					d1planar1x1[ch][i][j] = *(input_data + (startRow + i) * OFFCHIP_WIDTH + startCol + j + i*(9-9) + ch*9*9);
				}
			}
		}

		kchin1 = 0;
		label19:for (int ch = 0; ch < 1024; ch++)
		{
			label20:for (int i = 0; i < 3; i++)
			{
				label21:for (int j = 0; j < 3; j++)
				{
					xbufferw1[ch][i][j] = *(conv9_dw+ kchin1);
					kchin1++;
				}
			}
		}

		label22:for (int ch = 0; ch < 1024; ch=ch+32)
		{
			fun_dw1(d1planar1x1[ch],xbufferw1[ch],dw_out_buff[ch]);
			fun_dw1(d1planar1x1[ch+1],xbufferw1[ch+1],dw_out_buff[ch+1]);
			fun_dw1(d1planar1x1[ch+2],xbufferw1[ch+2],dw_out_buff[ch+2]);
			fun_dw1(d1planar1x1[ch+3],xbufferw1[ch+3],dw_out_buff[ch+3]);
			fun_dw1(d1planar1x1[ch+4],xbufferw1[ch+4],dw_out_buff[ch+4]);
			fun_dw1(d1planar1x1[ch+5],xbufferw1[ch+5],dw_out_buff[ch+5]);
			fun_dw1(d1planar1x1[ch+6],xbufferw1[ch+6],dw_out_buff[ch+6]);
			fun_dw1(d1planar1x1[ch+7],xbufferw1[ch+7],dw_out_buff[ch+7]);
			fun_dw1(d1planar1x1[ch+8],xbufferw1[ch+8],dw_out_buff[ch+8]);
			fun_dw1(d1planar1x1[ch+9],xbufferw1[ch+9],dw_out_buff[ch+9]);
			fun_dw1(d1planar1x1[ch+10],xbufferw1[ch+10],dw_out_buff[ch+10]);
			fun_dw1(d1planar1x1[ch+11],xbufferw1[ch+11],dw_out_buff[ch+11]);
			fun_dw1(d1planar1x1[ch+12],xbufferw1[ch+12],dw_out_buff[ch+12]);
			fun_dw1(d1planar1x1[ch+13],xbufferw1[ch+13],dw_out_buff[ch+13]);
			fun_dw1(d1planar1x1[ch+14],xbufferw1[ch+14],dw_out_buff[ch+14]);
			fun_dw1(d1planar1x1[ch+15],xbufferw1[ch+15],dw_out_buff[ch+15]);
			fun_dw1(d1planar1x1[ch+16],xbufferw1[ch+16],dw_out_buff[ch+16]);
			fun_dw1(d1planar1x1[ch+17],xbufferw1[ch+17],dw_out_buff[ch+17]);
			fun_dw1(d1planar1x1[ch+18],xbufferw1[ch+18],dw_out_buff[ch+18]);
			fun_dw1(d1planar1x1[ch+19],xbufferw1[ch+19],dw_out_buff[ch+19]);
			fun_dw1(d1planar1x1[ch+20],xbufferw1[ch+20],dw_out_buff[ch+20]);
			fun_dw1(d1planar1x1[ch+21],xbufferw1[ch+21],dw_out_buff[ch+21]);
			fun_dw1(d1planar1x1[ch+22],xbufferw1[ch+22],dw_out_buff[ch+22]);
			fun_dw1(d1planar1x1[ch+23],xbufferw1[ch+23],dw_out_buff[ch+23]);
			fun_dw1(d1planar1x1[ch+24],xbufferw1[ch+24],dw_out_buff[ch+24]);
			fun_dw1(d1planar1x1[ch+25],xbufferw1[ch+25],dw_out_buff[ch+25]);
			fun_dw1(d1planar1x1[ch+26],xbufferw1[ch+26],dw_out_buff[ch+26]);
			fun_dw1(d1planar1x1[ch+27],xbufferw1[ch+27],dw_out_buff[ch+27]);
			fun_dw1(d1planar1x1[ch+28],xbufferw1[ch+28],dw_out_buff[ch+28]);
			fun_dw1(d1planar1x1[ch+29],xbufferw1[ch+29],dw_out_buff[ch+29]);
			fun_dw1(d1planar1x1[ch+30],xbufferw1[ch+30],dw_out_buff[ch+30]);
			fun_dw1(d1planar1x1[ch+31],xbufferw1[ch+31],dw_out_buff[ch+31]);
		}

		label23:for (int ch = 0; ch < 1024; ch=ch+32)
		{
			fun_bn1(&dw_out_buff[ch],32, &gamma[ch], &beta[ch], &batch_mean[ch], &batch_variance[ch], &dw_bn_out[ch]);
		}

		kchin2=0;
		label24:for (int i = 0; i < 1024; i++)
		{
			label25:for (int j = 0; j < 1024; j++)
			{
				if(i<512)
				{
					pw_w_buf1[i][j] = *(conv9_pw+ kchin2 );
				}
				else
				{
					pw_w_buf2[i-512][j] = *(conv9_pw+ kchin2 );
				}
				kchin2++;
			}
		}
				
		label26:for (int cho = 0; cho < 512; cho++)
		{
			label27:for (int chi = 0; chi < 1024; chi=chi+32)
			{
				fun_pw1(&dw_bn_out[chi], 32, &pw_w_buf1[cho][chi], &pw_out_buf1[cho], 1);
				fun_pw1(&dw_bn_out[chi], 32, &pw_w_buf2[cho][chi], &pw_out_buf2[cho], 1);
			}
		}

		label28:for (int cho = 0; cho < 512; cho=cho+64)
		{
			fun_bn2(&pw_out_buf1[cho],32, &pw_out_buf1[cho+32], &gamma1[cho], &beta1[cho], &batch_mean1[cho], &batch_variance1[cho], &out_bn2_buf1[cho],64);
			fun_bn2(&pw_out_buf2[cho],32, &pw_out_buf2[cho+32], &gamma1[cho+512], &beta1[cho+512], &batch_mean1[cho+512], &batch_variance1[cho+512], &out_bn2_buf2[cho],64);
		}

		int startRow1 = (tileIndex / 1) * 7;
		int startCol1 = (tileIndex % 1) * 7;

		label29:for (int cho = 0; cho < 1024; cho++)
		{
			label30:for (int r = 0; r < 7; r++)
			{
				label31:for (int c = 0; c < 7; c++)
				{
					if(cho<512)
					{
						*(output_data + (startRow1 + r) * OFFCHIP_WIDTH1 + startCol1 + c + cho*7*7 ) = out_bn2_buf1[cho][r][c];
					}
					else
					{
						*(output_data + (startRow1 + r) * OFFCHIP_WIDTH1 + startCol1 + c + cho*7*7 ) = out_bn2_buf2[cho][r][c];
					}
				}
			}
		}
		//	printf("\n");

     }
}
