#include <stdio.h>
#include <math.h>

void  mobly1_act(
    float *conv1d_w,
    float *conv1p_w,
	float *input_data,
    float *output_data
);

int  main()

{


#include "D:\\mobilenet\\mobly1_act\\conv1d_weight.txt"
#include "D:\\mobilenet\\mobly1_act\\conv1p_weight.txt"

#include "D:\\mobilenet\\mobly1_act\\conv1d_inp.txt"


static float InputData[114*114*32];
static float OutputData[112*112*64];

static float conv1d_w1[32*3*3];
static float conv1p_w1[64*32];
static float output_buf1[64][112][112];

int count=0;
int cnt = 0;
int cnt1=0;
	
static float input1d[32][114][114];
for(int chi = 0; chi < 32; chi++) {
	for(int r = 0; r < 114; r++) {
		for(int c = 0; c < 114; c++) {
			if ((r > 0 && r < 113) && (c > 0 && c < 113)) {
				input1d[chi][r][c] = conv1d_inp[0][r - 1][c - 1][chi];
					
			}
			else {
				input1d[chi][r][c] = 0;
			}
		}
	}
}
	
	
	count=0;
	for(int ch=0;ch<32;ch++)
	{
		for(int r=0;r<112;r++)
		{
			for(int c=0;c<112;c++)
			{
				InputData[count] = input1d[ch][r][c];
				count++;
			}
		}
	}

	cnt=0;
	for(int ch=0;ch<32;ch++)
	{
		for(int r=0;r<3;r++)
		{
			for(int c=0;c<3;c++)
			{
				conv1d_w1[cnt] = conv1d_w[r][c][ch];
				cnt++;
			}
		}
	}


	cnt1=0;
	for(int ch=0;ch<64;ch++)
	{
		for(int ci=0;ci<32;ci++)
		{
			for(int r=0;r<1;r++)
			{
				for(int c=0;c<1;c++)
				{
					conv1p_w1[cnt1] = conv1p_w[r][c][ci][ch];
					cnt1++;
				}
			}
		}
	}

	mobly1_act(conv1d_w1, conv1p_w1, InputData,OutputData);

	//printf("tb data address is \t  %f \t \n",InputData[0]);

	int cnt2 = 0;
	for(int ch=0;ch<3;ch++)
	{
		for(int r=0;r<112;r++)
		{
			for(int c=0;c<112;c++)
			{
				//printf("%f \t", &OutputData[cnt2]);
				cnt2++;
			}
			//printf("\n");
		}
		//printf("\n");
	}
	//printf("\n");



int cnt3=0;

	for(int ch=0;ch<32;ch++)
	{
		for(int r=0;r<3;r++)
		{
			for(int c=0;c<3;c++)
			{
				//printf("%d \t", &conv1d_w1[cnt3]);
				cnt3++;
			}
			//printf("\n");
		}
		//printf("\n");
	}
	//printf("\n");


int cnt4=0;
	for(int ch=0;ch<64;ch++)
	{
		for(int c=0;c<32;c++)
		{
			//printf("%d \t",&conv1p_w1[cnt4]);
			cnt4++;
		}
		//printf("\n");
	}
	//printf("\n");


	int cnt5 = 0;
		for(int ch=0;ch<64;ch++)
		{
			for(int r=0;r<112;r++)
			{
				for(int c=0;c<112;c++)
				{
					//printf("%d \t", &OutputData[cnt5]);
					cnt5++;
				}
				//printf("\n");
			}
			//printf("\n");
		}
		//printf("\n");

		int cnt6=0;
		for(int ch=0;ch<64;ch++){
			for(int r=0;r<112;r++){
				for(int c=0;c<112;c++){
					output_buf1[ch][r][c]=OutputData[cnt6];
					cnt6++;
				}
			}
		}

		for(int ch=0;ch<3;ch++)
		{
			for(int r=0;r<5;r++)
			{
				for(int c=0;c<5;c++)
				{
					printf("%f \t",output_buf1[ch][r][c]);
				}
				printf("\n");
			}
			printf("\n");
		}
		printf("\n");

return 0;

}
