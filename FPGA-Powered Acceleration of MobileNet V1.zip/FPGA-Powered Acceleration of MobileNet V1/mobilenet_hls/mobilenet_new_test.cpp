#include <stdio.h>
#include <math.h>

//void  PE_array(float *conv_w, float *input_data, float *output_data, int input_R,int CONV_CHin, int CONV_CHout);

void  mobilenet(
    float *conv1_w,
    float *conv1d_w,
    float *conv1p_w,
    float *input_data,
    float *output_data
);

int  main()
{

#include "E:\\mobilenet_hls\\conv1_weight.txt"
//#include "E:\\mobilenet_hls\\conv1d_weight.txt"
#include "E:\\mobilenet_hls\\ly5w.txt"
#include "E:\\mobilenet_hls\\conv1P_weight.txt"
#include "E:\\mobilenet_hls\\test_images1_new.txt"
#include "E:\\mobilenet_hls\\testlabels5.txt"

float InputData[224*224*3];
static float OutputData[112*112*32];

int outvalue;
int count=0;
int cnt=0;
int index;
float maxvalue;
int p=0,q=0;
float acc;

for(int i=0;i<1;i++)
{
	count=0;
	for(int j=0;j<224;j++)
	{
		for(int k=0;k<224;k++)
		{
			for(int l=0;l<3;l++)
			{
				InputData[count] = testimages[i][j][k][l];
				count++;					
				cnt++;
			}
		}
	}
}

mobilenet(conv1_w, conv1d_w,conv1p_w,InputData,OutputData);


return 0;

}


