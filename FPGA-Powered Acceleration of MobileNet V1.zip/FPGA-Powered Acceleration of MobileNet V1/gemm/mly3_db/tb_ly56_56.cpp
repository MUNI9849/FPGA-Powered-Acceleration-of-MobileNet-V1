#include <stdio.h>
#include <math.h>

void  mobilenet(
    float *conv3d_w,
    float *conv3p_w,
	float *input_data,
    float *output_data
);

int  main()

{

#include "D:\Term_Paper\ly56_56\conv3d_weight.txt"
#include "D:\Term_Paper\ly56_56\conv3p_weight.txt"

#include "D:\Term_Paper\ly56_56\conv3d_inp.txt"


static float InputData[58*58*128];
static float OutputData[56*56*128];

static float conv3d_w1[128*3*3];
static float conv3p_w1[128*128];
static float output_buf3[128][56][56];

int count=0;
int cnt = 0;
int cnt1=0;
	
static float input3d[128][58][58];
for(int chi = 0; chi < 128; chi++) {
	for(int r = 0; r < 58; r++) {
		for(int c = 0; c < 58; c++) {
			if ((r > 0 && r < 57) && (c > 0 && c < 57)) {
				input3d[chi][r][c] = conv3d_inp[r - 1][c - 1][chi];
					
			}
			else {
				input3d[chi][r][c] = 0;
			}
		}
	}
}

	count=0;
	for(int ch=0;ch<128;ch++)
	{
		for(int r=0;r<58;r++)
		{
			for(int c=0;c<58;c++)
			{
				InputData[count] = input3d[ch][r][c];
				count++;
			}
		}
	}

	cnt=0;
	for(int ch=0;ch<128;ch++)
	{
		for(int r=0;r<3;r++)
		{
			for(int c=0;c<3;c++)
			{
				conv3d_w1[cnt] = conv3d_w[r][c][ch];
				cnt++;
			}
		}
	}

	cnt1=0;
	for(int ch=0;ch<128;ch++)
	{
		for(int ci=0;ci<128;ci++)
		{
			for(int r=0;r<1;r++)
			{
				for(int c=0;c<1;c++)
				{
					conv3p_w1[cnt1] = conv3p_w[r][c][ci][ch];
					cnt1++;
				}
			}
		}
	}


	mobilenet(conv3d_w1, conv3p_w1, InputData,OutputData);
	
	int cnt2 = 0;
	for(int ch=0;ch<128;ch++)
	{
		for(int r=0;r<58;r++)
		{
			for(int c=0;c<58;c++)
			{
				//printf("%d \t", &InputData[cnt2]);
				cnt2++;
			}
			//printf("\n");
		}
		//printf("\n");
	}
	//printf("\n");


	int cnt3=0;
	for(int ch=0;ch<128;ch++)
	{
		for(int r=0;r<3;r++)
		{
			for(int c=0;c<3;c++)
			{
				//printf("%d \t", &conv3d_w1[cnt3]);
				cnt3++;
			}
			//printf("\n");
		}
		//printf("\n");
	}
	//printf("\n");


	int cnt4=0;
	for(int ch=0;ch<128;ch++)
	{
		for(int c=0;c<128;c++)
		{
			//printf("%d \t",&conv3p_w1[cnt4]);
			cnt4++;
		}
		//printf("\n");
	}
	//printf("\n");


	int cnt5 = 0;
	for(int ch=0;ch<128;ch++)
	{
		for(int r=0;r<56;r++)
		{
			for(int c=0;c<56;c++)
			{
				//printf("%d \t", &OutputData[cnt5]);
				cnt5++;
			}
			//printf("\n");
		}
		//printf("\n");
	}
	//printf("\n");


	int cnt6 = 0;
	for(int ch=0;ch<1;ch++)
	{
		for(int r=0;r<56;r++)
		{
			for(int c=0;c<56;c++)
			{
				printf("%f \t", OutputData[cnt6]);
				cnt6++;
			}
			printf("\n");
		}
		printf("\n");
	}
	printf("\n");

return 0;

}
