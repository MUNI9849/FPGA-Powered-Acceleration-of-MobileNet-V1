void hls_div(float *a, float *b, float *c)
{

#pragma HLS INTERFACe s_axilite port=return bundle=CRTLS


#pragma HLS INTERFACE m_axi depth=256 port=a offset=slave bundle=a_port
#pragma HLS INTERFACE s_axilite port=a
#pragma HLS INTERFACE m_axi depth=256 port=b offset=slave bundle=b_port
#pragma HLS INTERFACE s_axilite port=b
#pragma HLS INTERFACE m_axi depth=256 port=c offset=slave bundle=c_port
#pragma HLS INTERFACE s_axilite port=c

float a_in[20];
float b_in[20];
float c_in[20];

for(int i=0;i<20;i++)
{
	a_in[i] = *a++;

}

for(int i=0;i<20;i++)
{

	b_in[i] = *b++;
}

for(int i=0;i<20;i++)
{
	c_in[i] = a_in[i] / b_in[i];
}

for(int i=0;i<20;i++)
{
	*c++ = c_in[i];
}

}
