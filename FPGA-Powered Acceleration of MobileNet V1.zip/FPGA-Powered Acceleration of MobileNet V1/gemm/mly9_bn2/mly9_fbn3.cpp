#include<stdio.h>
#include "math.h"
#include "datatype.h"
#include "fxp_sqrt.h"
#include "fxp_sqrt_top.h"

#include <cmath>
#include <cstdio>
#include <cstdlib>

out_data_t fxp_sqrt_top(in_data_t& in_val) {
    out_data_t result;
    //in_val= 4.0;
    fxp_sqrt(result, in_val);
    return result;
}

void  mly9_fbn3(
	T16 *input_data1,
	T16 *gamma,
	T16 *beta,
	T16 *mean,
	T16 *var,
    T16 *output_data1
)
{
#pragma HLS INTERFACE m_axi depth=1024 port=input_data1 offset=slave bundle=input1
#pragma HLS INTERFACE s_axilite port=input_data1
	
#pragma HLS INTERFACE m_axi depth=1024 port=gamma offset=slave bundle=pgamma
#pragma HLS INTERFACE s_axilite port=gamma
#pragma HLS INTERFACE m_axi depth=1024 port=beta offset=slave bundle=pbeta
#pragma HLS INTERFACE s_axilite port=beta
#pragma HLS INTERFACE m_axi depth=1024 port=mean offset=slave bundle=pmean
#pragma HLS INTERFACE s_axilite port=mean
#pragma HLS INTERFACE m_axi depth=1024 port=var offset=slave bundle=pvar
#pragma HLS INTERFACE s_axilite port=var

#pragma HLS INTERFACE m_axi depth=1024 port=output_data1 offset=slave bundle=output1
#pragma HLS INTERFACE s_axilite port=output_data1
#pragma HLS INTERFACE s_axilite port=return

	T16 bgamma[1000];
	#pragma HLS array_partition variable=bgamma cyclic factor=1 dim=1
	T16 bbeta[1000];
	#pragma HLS array_partition variable=bbeta cyclic factor=1 dim=1
	T16 bmean[1000];
	#pragma HLS array_partition variable=bmean cyclic factor=1 dim=1
	T16 bvar[1000];
	#pragma HLS array_partition variable=bvar cyclic factor=1 dim=1
	
    in_data_t dbufA_ping[1000];
	#pragma HLS array_partition variable=dbufA_ping cyclic factor=1 dim=1 
    in_data_t outbuf_ping[1000];
	#pragma HLS array_partition variable=outbuf_ping cyclic factor=1 dim=1  
	
	Loop_x1:for(int x=0;x<1000;x++)
	{
			dbufA_ping[x] = *input_data1++;
	}
		/*bgamma[x] = *gamma++;
		bbeta[x] = *beta++;
		bmean[x] = *mean++;
		bvar[x] = *var++;*/
	
	
	T16 temp = 1e-3;
	T16 tx2[1000];
	T16 tx3[1000];
	T16 normalized_value[1000];
	T16 scaled_value[1000];
	in_data_t testx;
	in_data_t tx1;
	Loop_x3:for(int cho=0;cho<1000;cho++){		
					//outbuf_ping[cho] = fxp_sqrt_top(dbufA_ping[cho]);
				testx = bvar[cho]+temp;
				tx1 = fxp_sqrt_top(testx);					
					tx2[cho] = dbufA_ping[cho] - bmean[cho];
					normalized_value[cho] = tx2[cho] / tx1;
					tx3[cho] = bgamma[cho] * normalized_value[cho];
					outbuf_ping[cho] = tx3[cho] + bbeta[cho]; 								
	}	
					
	Loop_x5: for(int x=0;x<1000;x++)
	{
			*output_data1++ = outbuf_ping[x];
	}		
}

/*
	Loop_x3:for(int cho=0;cho<32;cho++){		
		testx = varx[cho]+temp;
		tx1 = fxp_sqrt_top(testx);
		Loop_x4:for(int r=0;r<49;r++){
					tx2[r] = dbufA_ping[cho][r] - bmeanx[cho];
					normalized_value[r] = tx2[r] / tx1;
					tx3[r] = bgammax[cho] * normalized_value[r];
					outbuf_ping[cho][r] = tx3[r] + bbetax[cho]; 
			}
	}	
	
	
	
	
		T16 bgamma[32];
	#pragma HLS array_partition variable=bgamma cyclic factor=1 dim=1
	T16 bbeta[32];
	#pragma HLS array_partition variable=bbeta cyclic factor=1 dim=1
	T16 bmean[32];
	#pragma HLS array_partition variable=bmean cyclic factor=1 dim=1
	T16 bvar[32];
	#pragma HLS array_partition variable=bvar cyclic factor=1 dim=1
	
    in_data_t dbufA_ping[32][49];
	#pragma HLS array_partition variable=dbufA_ping cyclic factor=1 dim=1 
    in_data_t outbuf_ping[32][49];
	#pragma HLS array_partition variable=outbuf_ping cyclic factor=1 dim=1  
	
	Loop_x1:for(int x=0;x<32;x++)
	{
		Loop_x2:for(int y=0;y<49;y++)
		{
			dbufA_ping[x][y] = *input_data1++;
		}
		bgamma[x] = *gamma++;
		bbeta[x] = *beta++;
		bmean[x] = *mean++;
		bvar[x] = *var++;
	}
	
	T16 temp = 1e-3;
	T16 tx2[49];
	T16 tx3[49];
	T16 normalized_value[49];
	T16 scaled_value[49];
	in_data_t testx;
	in_data_t tx1;
	Loop_x3:for(int cho=0;cho<32;cho++){		
		//testx = varx[cho]+temp;
		//tx1 = fxp_sqrt_top(testx);
		Loop_x4:for(int r=0;r<49;r++){
					/*tx2[r] = dbufA_ping[cho][r] - bmeanx[cho];
					normalized_value[r] = tx2[r] / tx1;
					tx3[r] = bgammax[cho] * normalized_value[r];
					outbuf_ping[cho][r] = tx3[r] + bbetax[cho]; */
			/*		outbuf_ping[cho][r] = fxp_sqrt_top(dbufA_ping[cho][r]);
			}
	}	
					
	Loop_x5: for(int x=0;x<32;x++)
	{
		Loop_x6: for(int y=0;y<49;y++)
		{
			*output_data1++ = outbuf_ping[x][y];
		}
	}
	
	
}
	
	*/
