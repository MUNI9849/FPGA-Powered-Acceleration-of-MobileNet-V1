#include <stdio.h>
#include <math.h>

void  mly9_bn2(
	float *input_data1,
	float *input_data2,
	float *input_data3,
	float *input_data4,
	float *gamma,
	float *beta,
	float *mean,
	float *var,
    float *output_data1,
    float *output_data2,
    float *output_data3,
    float *output_data4
);

int  main()
{

#include "D:\\mobilenet\\mobly9_act\\conv9d_weight.txt"
#include "D:\\mobilenet\\mobly9_act\\conv9p_weight.txt"

#include "D:\\mobilenet\\mobly9_act\\conv9d_inp.txt"

#include "D:\\mobilenet\\mobly9_act\\conv9p_1.txt"
#include "D:\\mobilenet\\mobly9_act\\conv9p_2.txt"
#include "D:\\mobilenet\\mobly9_act\\conv9p_3.txt"
#include "D:\\mobilenet\\mobly9_act\\conv9p_4.txt"

#pragma HLS array_partition variable=gamma1 complete dim=0
#pragma HLS array_partition variable=beta1 complete dim=0
#pragma HLS array_partition variable=batch_mean1 complete dim=0
#pragma HLS array_partition variable=batch_variance1 complete dim=0


static float InputData[9*9*1024];
static float OutputData[7*7*1024];

static float output_buf3[1024][7][7];

int count=0;
int cnt = 0;
int cnt1=0;
	
static float input9d[1024][9][9];
for(int chi = 0; chi < 1024; chi++) {
	for(int r = 0; r < 9; r++) {
		for(int c = 0; c < 9; c++) {
			if ((r > 0 && r < 8) && (c > 0 && c < 8)) {
				input9d[chi][r][c] = conv9d_inp[r - 1][c - 1][chi];					
			}
			else {
				input9d[chi][r][c] = 0;
			}
		}
	}
}

	count=0;
	for(int ch=0;ch<1024;ch++)
	{
		for(int r=0;r<9;r++)
		{
			for(int c=0;c<9;c++)
			{
				//InputData[count] = input9d[ch][r][c];
				InputData[count] = 2.0;
				count++;
			}
		}
	}



	mly9_bn2(InputData,InputData,InputData,InputData,gamma1 ,beta1 ,batch_mean1 ,batch_variance1 ,OutputData ,OutputData ,OutputData ,OutputData);

	int cnt6 = 0;
	for(int ch=0;ch<32;ch++)
	{
		for(int r=0;r<7;r++)
		{
			for(int c=0;c<7;c++)
			{
			//	printf("%f \t", OutputData[cnt6]);
				cnt6++;
			}
		//	printf("\n");
		}
		//printf("\n");
	}
	//printf("\n");

return 0;
}



