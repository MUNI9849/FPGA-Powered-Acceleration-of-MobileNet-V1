#include<stdio.h>
#include "math.h"
#include "datatype.h"

void write_off(T16 *out1,T16 *out2, T16 *out3, T16 *out4, T16 (*out_buf)[64],int kcho, int ch)
{	
	if(ch > 0)
	{					loop_wr1:for(int x=0;x<7;x++)	
						{
							loop_wr2:for (int cho = 0; cho < 64; cho=cho+4)
							{
										*(out1 + kcho)     = out_buf[x][cho];
										*(out2 + kcho + 1) = out_buf[x][cho+1];
										*(out3 + kcho + 2) = out_buf[x][cho+2];
										*(out4 + kcho + 3) = out_buf[x][cho+3];
										kcho = kcho + 4;
							}	
						}
	}
}

void read_data(T16 (*in_buf)[32], T16 *inp1, T16 *inp2, T16 *inp3, T16 *inp4,int kchd, int ch)
{
						if(ch < 31)
						{		
												loop_rd1:for(int x=0;x<7;x++)
												{
													loop_rd2: for(int ch_inp=0;ch_inp<32;ch_inp = ch_inp+4)
													{
																in_buf[x][ch_inp  ] = *(inp1 +  (ch_inp    ) + kchd);				
																in_buf[x][ch_inp+1] = *(inp2 +  (ch_inp + 1) + kchd + 1);	
																in_buf[x][ch_inp+2] = *(inp3 +  (ch_inp + 2) + kchd + 2);	
																in_buf[x][ch_inp+3] = *(inp4 +  (ch_inp + 3) + kchd + 3);
																kchd = kchd+4;	
													}	
												}
						}
}

void read_wts(T16 (*wt_buf)[64], T16 *inpwt1, T16 *inpwt2, T16 *inpwt3, T16 *inpwt4, int kch, int ch)
{
						if(ch < 31)
						{	
													loop_rw1: for(int ch_inp=0; ch_inp<64 ;ch_inp = ch_inp+4)
													{			
														loop_rw2:for (int x = 0; x < 32; x++)
														{
																wt_buf[x][ch_inp  ] = *(inpwt1 + kch);												
																wt_buf[x][ch_inp+1] = *(inpwt2 + kch + 1);												
																wt_buf[x][ch_inp+2] = *(inpwt3 + kch + 2);												
																wt_buf[x][ch_inp+3] = *(inpwt4 + kch + 3);
																kch = kch + 8 ;																								
														}		
													}	
						}
}

/*
void fun_mul(T16 A[32], T16 (*B)[64], T16 temp[64])
{
    loop_mul2: for (int j = 0; j < 64; j++) {
      loop_mul3: for (int k = 0; k < 32; k++) {      	
        temp[j] += A[k] * B[k][j];
      }
    }
}
*/
void fun_mul(T16 A[32], T16 (*B)[64], T16 temp[64])
{
    #pragma HLS inline off
    #pragma HLS PIPELINE II=1

    T16 temp_reg[64];
    #pragma HLS array_partition variable=temp_reg complete

    // Initialize temporary register
    for (int j = 0; j < 64; j++) {
        temp_reg[j] = 0;
    }

    // Perform multiplication and accumulation
    for (int k = 0; k < 32; k++) {
        for (int j = 0; j < 64; j++) {
            #pragma HLS UNROLL factor=2
            temp_reg[j] += A[k] * B[k][j];
        }
    }

    // Copy temporary register to output
    for (int j = 0; j < 64; j++) {
        temp[j] = temp_reg[j];
    }
}

void  mly9_fpw(
    T16 *conv9_s1pw1,
    T16 *conv9_s1pw2,
    T16 *conv9_s1pw3,
    T16 *conv9_s1pw4,
	T16 *input_data1,
	T16 *input_data2,
	T16 *input_data3,
	T16 *input_data4,
    T16 *output_data1,
    T16 *output_data2,
    T16 *output_data3,
    T16 *output_data4
)

{
#pragma HLS INTERFACE m_axi depth=1024 port=conv9_s1pw1 offset=slave bundle=wtw1
#pragma HLS INTERFACE s_axilite port=conv9_s1pw1
#pragma HLS INTERFACE m_axi depth=1024 port=conv9_s1pw2 offset=slave bundle=wtw2
#pragma HLS INTERFACE s_axilite port=conv9_s1pw2
#pragma HLS INTERFACE m_axi depth=1024 port=conv9_s1pw3 offset=slave bundle=wtw3
#pragma HLS INTERFACE s_axilite port=conv9_s1pw3
#pragma HLS INTERFACE m_axi depth=1024 port=conv9_s1pw4 offset=slave bundle=wtw4
#pragma HLS INTERFACE s_axilite port=conv9_s1pw4

#pragma HLS INTERFACE m_axi depth=1024 port=input_data1 offset=slave bundle=input1
#pragma HLS INTERFACE s_axilite port=input_data1
#pragma HLS INTERFACE m_axi depth=1024 port=input_data2 offset=slave bundle=input2
#pragma HLS INTERFACE s_axilite port=input_data2
#pragma HLS INTERFACE m_axi depth=1024 port=input_data3 offset=slave bundle=input3
#pragma HLS INTERFACE s_axilite port=input_data3
#pragma HLS INTERFACE m_axi depth=1024 port=input_data4 offset=slave bundle=input4
#pragma HLS INTERFACE s_axilite port=input_data4

#pragma HLS INTERFACE m_axi depth=1024 port=output_data1 offset=slave bundle=output1
#pragma HLS INTERFACE s_axilite port=output_data1
#pragma HLS INTERFACE m_axi depth=1024 port=output_data2 offset=slave bundle=output2
#pragma HLS INTERFACE s_axilite port=output_data2
#pragma HLS INTERFACE m_axi depth=1024 port=output_data3 offset=slave bundle=output3
#pragma HLS INTERFACE s_axilite port=output_data3
#pragma HLS INTERFACE m_axi depth=1024 port=output_data4 offset=slave bundle=output4
#pragma HLS INTERFACE s_axilite port=output_data4
#pragma HLS INTERFACE s_axilite port=return

    T16 dbufA_ping[7][32];
    T16 dbufA_pong[7][32];
	#pragma HLS array_partition variable=dbufA_ping cyclic factor=7 dim=1
	#pragma HLS array_partition variable=dbufA_pong cyclic factor=7 dim=1    
    T16 wbufA_ping[32][64];
    T16 wbufA_pong[32][64];
    T16 outbuf_ping[7][64];
    T16 outbuf_pong[7][64];
	#pragma HLS array_partition variable=outbuf_ping cyclic factor=7 dim=1
	#pragma HLS array_partition variable=outbuf_pong cyclic factor=7 dim=1    
	
	T16 temp_ping[7][64]={0};
	#pragma HLS array_partition variable=temp_ping cyclic factor=7 dim=1 
	
	T16 temp_pingx[7][64]={0};
	#pragma HLS array_partition variable=temp_pingx cyclic factor=7 dim=1 
	T16 temp_pingy[7][64]={0};
	#pragma HLS array_partition variable=temp_pingy cyclic factor=7 dim=1 		
	
	T16 temp_pong[7][64]={0};
	#pragma HLS array_partition variable=temp_pong cyclic factor=7 dim=1 
	T16 temp_pongx[7][64]={0};
	#pragma HLS array_partition variable=temp_pongx cyclic factor=7 dim=1 
	T16 temp_pongy[7][64]={0};
	#pragma HLS array_partition variable=temp_pongy cyclic factor=7 dim=1 		

    int OFFCHIP_WIDTH=9;
    int OFFCHIP_WIDTH1=7;
    int kchinx1=0;
    int kchiny1=0;
    int kchin2=0;
    int ch_inp = 0;
    int k=0;
    int kchdx1 = 0;
    int kchdy1 = 0;
    int kchox1 = 0;
    int kchoy1 = 0;
    	

							read_data(dbufA_ping, input_data1, input_data2, input_data3, input_data4,kchdx1 ,0);
							read_wts(wbufA_ping, conv9_s1pw1, conv9_s1pw2, conv9_s1pw3, conv9_s1pw4, kchiny1,0);	
							kchiny1 = kchiny1+4 ;		
							kchdx1 = kchdx1 + 4;							
															
											
	loop_sets:for(int set=0; set<16; set++)  // for each set, 64 output feature maps are generated.
	{
    	loop_tiles:for(int tileIndex=0;tileIndex<7;tileIndex++)  // 7x7 = 49 slides are required to cover complete feature map.
    	{ 	
			if(tileIndex %2 == 0)
			{
				loop_dep1:for (int ch = 0; ch < 32; ch++)  //1024/32=32 , here depth is covered.
				{
					if( ch % 2 == 0 )
					{		
						fun_mul(dbufA_ping[0], wbufA_ping, temp_ping[0]);
						fun_mul(dbufA_ping[1], wbufA_ping, temp_ping[1]);
						fun_mul(dbufA_ping[2], wbufA_ping, temp_ping[2]);
						fun_mul(dbufA_ping[3], wbufA_ping, temp_ping[3]);
						fun_mul(dbufA_ping[4], wbufA_ping, temp_ping[4]);
						fun_mul(dbufA_ping[5], wbufA_ping, temp_ping[5]);
						fun_mul(dbufA_ping[6], wbufA_ping, temp_ping[6]);
						for(int x=0;x<64;x++)
						{
							temp_pingx[0][x] = temp_pingx[0][x] + temp_ping[0][x];
							temp_pingx[1][x] = temp_pingx[1][x] + temp_ping[1][x];
							temp_pingx[2][x] = temp_pingx[2][x] + temp_ping[2][x];
							temp_pingx[3][x] = temp_pingx[3][x] + temp_ping[3][x];
							temp_pingx[4][x] = temp_pingx[4][x] + temp_ping[4][x];
							temp_pingx[5][x] = temp_pingx[5][x] + temp_ping[5][x];
							temp_pingx[6][x] = temp_pingx[6][x] + temp_ping[6][x];
						}
						
						loop_e1:for(int y=0;y<1;y++)
						{		
							read_data(dbufA_pong, input_data1, input_data2, input_data3, input_data4,kchdx1 , ch);
							read_wts(wbufA_pong, conv9_s1pw1, conv9_s1pw2, conv9_s1pw3, conv9_s1pw4, kchinx1, ch);
							kchinx1 = kchinx1 + 8;
							kchdx1 = kchdx1 + 8;
						}				
					}	
					else if( ch % 2 == 1 )
					{			
						fun_mul(dbufA_pong[0], wbufA_pong, temp_ping[0]);	
						fun_mul(dbufA_pong[1], wbufA_pong, temp_ping[1]);	
						fun_mul(dbufA_pong[2], wbufA_pong, temp_ping[2]);	
						fun_mul(dbufA_pong[3], wbufA_pong, temp_ping[3]);	
						fun_mul(dbufA_pong[4], wbufA_pong, temp_ping[4]);	
						fun_mul(dbufA_pong[5], wbufA_pong, temp_ping[5]);	
						fun_mul(dbufA_pong[6], wbufA_pong, temp_ping[6]);	
						for(int x=0;x<64;x++)
						{
							temp_pingy[0][x] = temp_pingy[0][x] + temp_ping[0][x];
							temp_pingy[1][x] = temp_pingy[1][x] + temp_ping[1][x];
							temp_pingy[2][x] = temp_pingy[2][x] + temp_ping[2][x];
							temp_pingy[3][x] = temp_pingy[3][x] + temp_ping[3][x];
							temp_pingy[4][x] = temp_pingy[4][x] + temp_ping[4][x];
							temp_pingy[5][x] = temp_pingy[5][x] + temp_ping[5][x];
							temp_pingy[6][x] = temp_pingy[6][x] + temp_ping[6][x];
						}													
				
						loop_e12:for(int y=0;y<1;y++)
						{			
							read_data(dbufA_ping, input_data1, input_data2, input_data3, input_data4,kchdy1 , ch);
							read_wts(wbufA_ping, conv9_s1pw1, conv9_s1pw2, conv9_s1pw3, conv9_s1pw4, kchiny1, ch);
							kchiny1 = kchiny1 + 8;
							kchdy1 = kchdy1 + 8;
						}
					}
				}
				loop_d12a:for(int y=0;y<1;y++)
				{	
						loop_d12c:for(int x=0;x<64;x++)
						{
							outbuf_ping[0][x]  =  temp_pongx[0][x] + temp_pongy[0][x];
							outbuf_ping[1][x]  =  temp_pongx[1][x] + temp_pongy[1][x];
							outbuf_ping[2][x]  =  temp_pongx[2][x] + temp_pongy[2][x];
							outbuf_ping[3][x]  =  temp_pongx[3][x] + temp_pongy[3][x];
							outbuf_ping[4][x]  =  temp_pongx[4][x] + temp_pongy[4][x];
							outbuf_ping[5][x]  =  temp_pongx[5][x] + temp_pongy[5][x];
							outbuf_ping[6][x]  =  temp_pongx[6][x] + temp_pongy[6][x];
							temp_pongx[0][x] = 0;
							temp_pongx[1][x] = 0;
							temp_pongx[2][x] = 0;
							temp_pongx[3][x] = 0;
							temp_pongx[4][x] = 0;
							temp_pongx[5][x] = 0;
							temp_pongx[6][x] = 0;
							temp_pongy[0][x] = 0;
							temp_pongy[1][x] = 0;
							temp_pongy[2][x] = 0;
							temp_pongy[3][x] = 0;
							temp_pongy[4][x] = 0;
							temp_pongy[5][x] = 0;
							temp_pongy[6][x] = 0;							
						}				
					write_off(output_data1, output_data2, output_data3, output_data4, outbuf_pong,kchox1 , tileIndex);	
					kchox1 = kchox1 + 8;    																											
				}				
			}
			else if(tileIndex %2 == 1)
			{
				l2oop_y1:for (int ch = 0; ch < 32; ch++)  //1024/32=32 , here depth is covered.
				{
					if( ch % 2 == 0 )
					{										
						fun_mul(dbufA_ping[0],wbufA_ping,temp_pong[0]);			
						fun_mul(dbufA_ping[1],wbufA_ping,temp_pong[1]);	
						fun_mul(dbufA_ping[2],wbufA_ping,temp_pong[2]);	
						fun_mul(dbufA_ping[3],wbufA_ping,temp_pong[3]);	
						fun_mul(dbufA_ping[4],wbufA_ping,temp_pong[4]);	
						fun_mul(dbufA_ping[5],wbufA_ping,temp_pong[5]);	
						fun_mul(dbufA_ping[6],wbufA_ping,temp_pong[6]);	
						for(int x=0;x<64;x++)
						{
							temp_pongx[0][x] = temp_pongx[0][x]  + temp_pong[0][x];
							temp_pongx[1][x] = temp_pongx[1][x]  + temp_pong[1][x];
							temp_pongx[2][x] = temp_pongx[2][x]  + temp_pong[2][x];
							temp_pongx[3][x] = temp_pongx[3][x]  + temp_pong[3][x];
							temp_pongx[4][x] = temp_pongx[4][x]  + temp_pong[4][x];
							temp_pongx[5][x] = temp_pongx[5][x]  + temp_pong[5][x];
							temp_pongx[6][x] = temp_pongx[6][x]  + temp_pong[6][x];
						}						
																						
						l2oop_y2:for(int y=0;y<1;y++)
						{		
							read_data(dbufA_pong, input_data1, input_data2, input_data3, input_data4,kchdx1 , ch);
							read_wts(wbufA_pong, conv9_s1pw1, conv9_s1pw2, conv9_s1pw3, conv9_s1pw4, kchinx1, ch);
							kchinx1 = kchinx1 + 8;
							kchdx1 = kchdx1 + 8;
						}				
					}	
					else if( ch % 2 == 1 )
					{			
						fun_mul(dbufA_pong[0],wbufA_pong,temp_pong[0]);												
						fun_mul(dbufA_pong[1],wbufA_pong,temp_pong[1]);	
						fun_mul(dbufA_pong[2],wbufA_pong,temp_pong[2]);	
						fun_mul(dbufA_pong[3],wbufA_pong,temp_pong[3]);	
						fun_mul(dbufA_pong[4],wbufA_pong,temp_pong[4]);	
						fun_mul(dbufA_pong[5],wbufA_pong,temp_pong[5]);	
						fun_mul(dbufA_pong[6],wbufA_pong,temp_pong[6]);	
						for(int x=0;x<64;x++)
						{
							temp_pongy[0][x] = temp_pongy[0][x] + temp_pong[0][x];
							temp_pongy[1][x] = temp_pongy[1][x] + temp_pong[1][x];
							temp_pongy[2][x] = temp_pongy[2][x] + temp_pong[2][x];
							temp_pongy[3][x] = temp_pongy[3][x] + temp_pong[3][x];
							temp_pongy[4][x] = temp_pongy[4][x] + temp_pong[4][x];
							temp_pongy[5][x] = temp_pongy[5][x] + temp_pong[5][x];
							temp_pongy[6][x] = temp_pongy[6][x] + temp_pong[6][x];
						}								

						l2oop_y3:for(int y=0;y<1;y++)
						{			
							read_data(dbufA_ping, input_data1, input_data2, input_data3, input_data4,kchdy1 , ch);
							read_wts(wbufA_ping, conv9_s1pw1, conv9_s1pw2, conv9_s1pw3, conv9_s1pw4, kchiny1, ch);
							kchiny1 = kchiny1 + 8;
							kchdy1 = kchdy1 + 8;
						}
					}
				}	
				l2oop_y4:for(int y=0;y<1;y++)
				{	
						l2oop_y6:for(int x=0;x<64;x++)
						{
							outbuf_pong[0][x]  =  temp_pingx[0][x] + temp_pingy[0][x];
							outbuf_pong[1][x]  =  temp_pingx[1][x] + temp_pingy[1][x];
							outbuf_pong[2][x]  =  temp_pingx[2][x] + temp_pingy[2][x];
							outbuf_pong[3][x]  =  temp_pingx[3][x] + temp_pingy[3][x];
							outbuf_pong[4][x]  =  temp_pingx[4][x] + temp_pingy[4][x];
							outbuf_pong[5][x]  =  temp_pingx[5][x] + temp_pingy[5][x];
							outbuf_pong[6][x]  =  temp_pingx[6][x] + temp_pingy[6][x];															
							temp_pingx[0][x] = 0;
							temp_pingx[1][x] = 0;
							temp_pingx[2][x] = 0;
							temp_pingx[3][x] = 0;
							temp_pingx[4][x] = 0;
							temp_pingx[5][x] = 0;
							temp_pingx[6][x] = 0;
							temp_pingy[0][x] = 0;
							temp_pingy[1][x] = 0;
							temp_pingy[2][x] = 0;
							temp_pingy[3][x] = 0;
							temp_pingy[4][x] = 0;
							temp_pingy[5][x] = 0;
							temp_pingy[6][x] = 0;							
						}
					
					write_off(output_data1, output_data2, output_data3, output_data4, outbuf_ping,kchoy1 , tileIndex);	
					kchoy1 = kchoy1 + 8;																													
				}															
			}																																			
    	}
	}
}



