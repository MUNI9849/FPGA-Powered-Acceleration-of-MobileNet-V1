#include <stdio.h>
#include <math.h>

void  mly9_pw(
    float *conv9_s1pw1,
    float *conv9_s1pw2,
    float *conv9_s1pw3,
    float *conv9_s1pw4,
	float *input_data1,
	float *input_data2,
	float *input_data3,
	float *input_data4,
    float *output_data1,
    float *output_data2,
    float *output_data3,
    float *output_data4
);

int  main()
{

#include "D:\\mobilenet\\mobly9_act\\conv9d_weight.txt"
#include "D:\\mobilenet\\mobly9_act\\conv9p_weight.txt"

#include "D:\\mobilenet\\mobly9_act\\conv9d_inp.txt"


static float InputData[9*9*1024];
static float OutputData[7*7*1024];

static float conv9p_w1[1024*1024];
static float output_buf3[1024][7][7];

int count=0;
int cnt = 0;
int cnt1=0;
	
static float input9d[1024][9][9];
for(int chi = 0; chi < 1024; chi++) {
	for(int r = 0; r < 9; r++) {
		for(int c = 0; c < 9; c++) {
			if ((r > 0 && r < 8) && (c > 0 && c < 8)) {
				input9d[chi][r][c] = conv9d_inp[r - 1][c - 1][chi];					
			}
			else {
				input9d[chi][r][c] = 0;
			}
		}
	}
}

	count=0;
	for(int ch=0;ch<1024;ch++)
	{
		for(int r=0;r<9;r++)
		{
			for(int c=0;c<9;c++)
			{
				//InputData[count] = input9d[ch][r][c];
				InputData[count] = 2.0;
				count++;
			}
		}
	}

	cnt1=0;
	for(int ch=0;ch<1024;ch++)
	{
		for(int ci=0;ci<1024;ci++)
		{
			for(int r=0;r<1;r++)
			{
				for(int c=0;c<1;c++)
				{
					//conv9p_w1[cnt1] = conv9p_w[r][c][ci][ch];
					conv9p_w1[cnt1] = 3.0;
					cnt1++;
				}
			}
		}
	}


	mly9_pw(conv9p_w1, conv9p_w1, conv9p_w1, conv9p_w1, InputData,InputData,InputData,InputData,OutputData,OutputData,OutputData,OutputData);
	
	int cnt2 = 0;
	for(int ch=0;ch<1024;ch++)
	{
		for(int r=0;r<9;r++)
		{
			for(int c=0;c<9;c++)
			{
			//	printf("%d \t", &InputData[cnt2]);
				cnt2++;
			}
			//printf("\n");
		}
		//printf("\n");
	}
	//printf("\n");


	int cnt3=0;
	for(int ch=0;ch<1024;ch++)
	{
		for(int r=0;r<3;r++)
		{
			for(int c=0;c<3;c++)
			{
				//printf("%d \t", &conv9d_w1[cnt3]);
				cnt3++;
			}
			//printf("\n");
		}
		//printf("\n");
	}
	//printf("\n");


	int cnt4=0;
	for(int ch=0;ch<1024;ch++)
	{
		for(int c=0;c<1024;c++)
		{
			//printf("%d \t",&conv9p_w1[cnt4]);
			cnt4++;
		}
		//printf("\n");
	}
	//printf("\n");


	int cnt5 = 0;
	for(int ch=0;ch<1024;ch++)
	{
		for(int r=0;r<7;r++)
		{
			for(int c=0;c<7;c++)
			{
				//printf("%d \t", &OutputData[cnt5]);
				cnt5++;
			}
			//printf("\n");
		}
	//	printf("\n");
	}
	//printf("\n");


	int cnt6 = 0;
	for(int ch=0;ch<32;ch++)
	{
		for(int r=0;r<7;r++)
		{
			for(int c=0;c<7;c++)
			{
			//	printf("%f \t", OutputData[cnt6]);
				cnt6++;
			}
		//	printf("\n");
		}
		//printf("\n");
	}
	//printf("\n");

return 0;
}
