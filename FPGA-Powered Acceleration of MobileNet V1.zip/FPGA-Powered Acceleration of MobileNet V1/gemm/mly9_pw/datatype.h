
#include "ap_fixed.h"
#include <hls_stream.h>


typedef ap_fixed<16, 4 > T16;

typedef ap_uint<8> d8u;
/*
	typedef struct {

		T8 Tile[49][16];
	} MyStructbig;
*/


