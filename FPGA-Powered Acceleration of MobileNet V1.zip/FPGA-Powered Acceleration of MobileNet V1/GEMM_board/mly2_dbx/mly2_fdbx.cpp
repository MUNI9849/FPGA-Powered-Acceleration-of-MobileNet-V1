#include<stdio.h>
#include "math.h"
#include "datatype.h"

void write_off(d8u *out1,d8u *out2, d8u *out3, d8u *out4, T16 (*out_buf)[7][7], int kchw, int ch)
{	
	if(ch > 0)
	{						

								loop_c14:for (int r = 0; r < 7; r++)
								{
									loop_c15:for (int c = 0; c < 7; c++)
									{
										loop_c13:for (int cho = 0; cho < 32; cho=cho+4)
										{										
										*(out1 + kchw ) 		= (d8u)out_buf[cho][r][c];
										*(out2 + kchw + 1) 		= (d8u)out_buf[cho+1][r][c];
										*(out3 + kchw + 2) 		= (d8u)out_buf[cho+2][r][c];
										*(out4 + kchw + 3) 		= (d8u)out_buf[cho+3][r][c];
										kchw = kchw + 4;
									}			
								}
							}	
	}
}








void read_data(T16 (*in_buf)[9][9], d8u *inp1, d8u *inp2, d8u *inp3, d8u *inp4, int kcd, int ch)
{
						if(ch < 31)
						{		
											
														loop_c7:for (int i = 0; i < 9; i++)
														{
															loop_c8:for (int j = 0; j < 9; j++)
															{
																		loop_c6: for(int ch_inp=0;ch_inp<32;ch_inp = ch_inp+4)
													{
																in_buf[ch_inp  ][i][j] = (T16)*(inp1 + kcd);				
																in_buf[ch_inp+1][i][j] = (T16)*(inp2 + kcd + 1);	
																in_buf[ch_inp+2][i][j] = (T16)*(inp3 + kcd + 2);	
																in_buf[ch_inp+3][i][j] = (T16)*(inp4 + kcd + 3);	
																kcd = kcd + 4;
															}
														}
													}	
						}
}


void read_wts(T16 (*wt_buf)[3][3], d8u *inpwt1, d8u *inpwt2, d8u *inpwt3, d8u *inpwt4, int kch, int ch)
{
						if(ch < 31)
						{	
			
														loop_c10:for (int i = 0; i < 3; i++)
														{
															loop_c11:for (int j = 0; j < 3; j++)
															{
													loop_c9: for(int ch_inp=0;ch_inp<32;ch_inp = ch_inp+4)
													{																
																wt_buf[ch_inp  ][i][j] = (T16)*(inpwt1 + kch);												
																wt_buf[ch_inp+1][i][j] = (T16)*(inpwt2 + kch + 1);												
																wt_buf[ch_inp+2][i][j] = (T16)*(inpwt3 + kch + 2);												
																wt_buf[ch_inp+3][i][j] = (T16)*(inpwt4 + kch + 3);
																kch = kch + 8 ;																								
															}
														}		
													}	
						}
}

void fun_dw1(T16 inp[9][9] , T16 cvw[3][3], T16 out[7][7])
{
    label1:for (int j = 0; j < 4; j++) {
    	label2:for (int m = 0; m < 4; m++) {
    		out[j][m] = 0;
    		label3:for (int x = 0; x < 3; x++) {
    			label4:for (int y = 0; y < 3; y++) {
                	out[j][m] += inp[j + x][m + y] * cvw[x][y];
                }
            }       
        }
    }
}

void  mly2_fdbx(
    d8u *conv9_dw1,
    d8u *conv9_dw2,
    d8u *conv9_dw3,
    d8u *conv9_dw4,
	d8u *input_data1,
	d8u *input_data2,
	d8u *input_data3,
	d8u *input_data4,
    d8u *output_data1,
    d8u *output_data2,
    d8u *output_data3,
    d8u *output_data4
)

{
#pragma HLS INTERFACE m_axi depth=1024 port=conv9_dw1 offset=slave bundle=conv9d1
#pragma HLS INTERFACE s_axilite port=conv9_dw1
#pragma HLS INTERFACE m_axi depth=1024 port=conv9_dw2 offset=slave bundle=conv9d2
#pragma HLS INTERFACE s_axilite port=conv9_dw2
#pragma HLS INTERFACE m_axi depth=1024 port=conv9_dw3 offset=slave bundle=conv9d3
#pragma HLS INTERFACE s_axilite port=conv9_dw3
#pragma HLS INTERFACE m_axi depth=1024 port=conv9_dw4 offset=slave bundle=conv9d4
#pragma HLS INTERFACE s_axilite port=conv9_dw4

#pragma HLS INTERFACE m_axi depth=1024 port=input_data1 offset=slave bundle=input1
#pragma HLS INTERFACE s_axilite port=input_data1
#pragma HLS INTERFACE m_axi depth=1024 port=input_data2 offset=slave bundle=input2
#pragma HLS INTERFACE s_axilite port=input_data2
#pragma HLS INTERFACE m_axi depth=1024 port=input_data3 offset=slave bundle=input3
#pragma HLS INTERFACE s_axilite port=input_data3
#pragma HLS INTERFACE m_axi depth=1024 port=input_data4 offset=slave bundle=input4
#pragma HLS INTERFACE s_axilite port=input_data4

#pragma HLS INTERFACE m_axi depth=1024 port=output_data1 offset=slave bundle=output1
#pragma HLS INTERFACE s_axilite port=output_data1
#pragma HLS INTERFACE m_axi depth=1024 port=output_data2 offset=slave bundle=output2
#pragma HLS INTERFACE s_axilite port=output_data2
#pragma HLS INTERFACE m_axi depth=1024 port=output_data3 offset=slave bundle=output3
#pragma HLS INTERFACE s_axilite port=output_data3
#pragma HLS INTERFACE m_axi depth=1024 port=output_data4 offset=slave bundle=output4
#pragma HLS INTERFACE s_axilite port=output_data4
#pragma HLS INTERFACE s_axilite port=return

    T16 dbufA_ping[32][9][9];
    T16 dbufA_pong[32][9][9];
	#pragma HLS array_partition variable=dbufA_ping cyclic factor=32 dim=1
	#pragma HLS array_partition variable=dbufA_pong cyclic factor=32 dim=1
    T16 wbufA_ping[32][3][3];
    T16 wbufA_pong[32][3][3];
	#pragma HLS array_partition variable=wbufA_ping cyclic factor=32 dim=1
	#pragma HLS array_partition variable=wbufA_pong cyclic factor=32 dim=1    
    T16 outbuf_ping[32][7][7];
    T16 outbuf_pong[32][7][7];
	#pragma HLS array_partition variable=outbuf_ping cyclic factor=32 dim=1
	#pragma HLS array_partition variable=outbuf_pong cyclic factor=32 dim=1   
	
    int OFFCHIP_WIDTH=9;
    int OFFCHIP_WIDTH1=7;
    int kchinx1=0;
    int kchiny1=0;
    int kchin2=0;
    int ch_inp = 0;
    int k=0;
    int kchdx = 0;
    int kchdy = 0;
    int kchox = 0;
    int kchoy = 0;     
    	
							read_data(dbufA_ping, input_data1, input_data2, input_data3, input_data4, kchdx, 0);
							read_wts(wbufA_ping, conv9_dw1, conv9_dw2, conv9_dw3, conv9_dw4, kchiny1,0);	
							kchiny1 = kchiny1+4 ;	
							kchdx = kchdx + 4;																	
																													
    			loop_c2:for(int tileIndex=0;tileIndex<256;tileIndex++) 
    			{ 							
		loop_c1:for (int ch = 0; ch < 32; ch++)  //1024/32=32
		{
			if( ch % 2 == 0 )
			{													
					fun_dw1(dbufA_ping[0],wbufA_ping[0],outbuf_ping[0]);
					fun_dw1(dbufA_ping[1],wbufA_ping[1],outbuf_ping[1]);
					fun_dw1(dbufA_ping[2],wbufA_ping[2],outbuf_ping[2]);
					fun_dw1(dbufA_ping[3],wbufA_ping[3],outbuf_ping[3]);
					fun_dw1(dbufA_ping[4],wbufA_ping[4],outbuf_ping[4]);
					fun_dw1(dbufA_ping[5],wbufA_ping[5],outbuf_ping[5]);
					fun_dw1(dbufA_ping[6],wbufA_ping[6],outbuf_ping[6]);
					fun_dw1(dbufA_ping[7],wbufA_ping[7],outbuf_ping[7]);
					fun_dw1(dbufA_ping[8],wbufA_ping[8],outbuf_ping[8]);
					fun_dw1(dbufA_ping[9],wbufA_ping[9],outbuf_ping[9]);
					fun_dw1(dbufA_ping[10],wbufA_ping[10],outbuf_ping[10]);
					fun_dw1(dbufA_ping[11],wbufA_ping[11],outbuf_ping[11]);
					fun_dw1(dbufA_ping[12],wbufA_ping[12],outbuf_ping[12]);
					fun_dw1(dbufA_ping[13],wbufA_ping[13],outbuf_ping[13]);
					fun_dw1(dbufA_ping[14],wbufA_ping[14],outbuf_ping[14]);
					fun_dw1(dbufA_ping[15],wbufA_ping[15],outbuf_ping[15]);
					fun_dw1(dbufA_ping[16],wbufA_ping[16],outbuf_ping[16]);
					fun_dw1(dbufA_ping[17],wbufA_ping[17],outbuf_ping[17]);
					fun_dw1(dbufA_ping[18],wbufA_ping[18],outbuf_ping[18]);
					fun_dw1(dbufA_ping[19],wbufA_ping[19],outbuf_ping[19]);
					fun_dw1(dbufA_ping[20],wbufA_ping[20],outbuf_ping[20]);
					fun_dw1(dbufA_ping[21],wbufA_ping[21],outbuf_ping[21]);
					fun_dw1(dbufA_ping[22],wbufA_ping[22],outbuf_ping[22]);
					fun_dw1(dbufA_ping[23],wbufA_ping[23],outbuf_ping[23]);
					fun_dw1(dbufA_ping[24],wbufA_ping[24],outbuf_ping[24]);
					fun_dw1(dbufA_ping[25],wbufA_ping[25],outbuf_ping[25]);
					fun_dw1(dbufA_ping[26],wbufA_ping[26],outbuf_ping[26]);
					fun_dw1(dbufA_ping[27],wbufA_ping[27],outbuf_ping[27]);
					fun_dw1(dbufA_ping[28],wbufA_ping[28],outbuf_ping[28]);
					fun_dw1(dbufA_ping[29],wbufA_ping[29],outbuf_ping[29]);
					fun_dw1(dbufA_ping[30],wbufA_ping[30],outbuf_ping[30]);
					fun_dw1(dbufA_ping[31],wbufA_ping[31],outbuf_ping[31]);		
				
					loop_d1:for(int x=0;x<1;x++)
					{					
							write_off(output_data1, output_data2, output_data3, output_data4, outbuf_pong, kchox, ch);																		
							kchox = kchox + 4;																								
						
					}
					loop_e1:for(int y=0;y<1;y++)
					{		
							read_data(dbufA_pong, input_data1, input_data2, input_data3, input_data4,kchdx, ch);
							read_wts(wbufA_pong, conv9_dw1, conv9_dw2, conv9_dw3, conv9_dw4, kchinx1, ch);
							kchinx1 = kchinx1 + 8;
							kchdx = kchdx + 4;							
					}
			}
			else if( ch % 2 == 1 )
			{															
					fun_dw1(dbufA_pong[0],wbufA_pong[0],outbuf_pong[0]);
					fun_dw1(dbufA_pong[1],wbufA_pong[1],outbuf_pong[1]);
					fun_dw1(dbufA_pong[2],wbufA_pong[2],outbuf_pong[2]);
					fun_dw1(dbufA_pong[3],wbufA_pong[3],outbuf_pong[3]);
					fun_dw1(dbufA_pong[4],wbufA_pong[4],outbuf_pong[4]);
					fun_dw1(dbufA_pong[5],wbufA_pong[5],outbuf_pong[5]);
					fun_dw1(dbufA_pong[6],wbufA_pong[6],outbuf_pong[6]);
					fun_dw1(dbufA_pong[7],wbufA_pong[7],outbuf_pong[7]);
					fun_dw1(dbufA_pong[8],wbufA_pong[8],outbuf_pong[8]);
					fun_dw1(dbufA_pong[9],wbufA_pong[9],outbuf_pong[9]);
					fun_dw1(dbufA_pong[10],wbufA_pong[10],outbuf_pong[10]);
					fun_dw1(dbufA_pong[11],wbufA_pong[11],outbuf_pong[11]);
					fun_dw1(dbufA_pong[12],wbufA_pong[12],outbuf_pong[12]);
					fun_dw1(dbufA_pong[13],wbufA_pong[13],outbuf_pong[13]);
					fun_dw1(dbufA_pong[14],wbufA_pong[14],outbuf_pong[14]);
					fun_dw1(dbufA_pong[15],wbufA_pong[15],outbuf_pong[15]);
					fun_dw1(dbufA_pong[16],wbufA_pong[16],outbuf_pong[16]);
					fun_dw1(dbufA_pong[17],wbufA_pong[17],outbuf_pong[17]);
					fun_dw1(dbufA_pong[18],wbufA_pong[18],outbuf_pong[18]);
					fun_dw1(dbufA_pong[19],wbufA_pong[19],outbuf_pong[19]);
					fun_dw1(dbufA_pong[20],wbufA_pong[20],outbuf_pong[20]);
					fun_dw1(dbufA_pong[21],wbufA_pong[21],outbuf_pong[21]);
					fun_dw1(dbufA_pong[22],wbufA_pong[22],outbuf_pong[22]);
					fun_dw1(dbufA_pong[23],wbufA_pong[23],outbuf_pong[23]);
					fun_dw1(dbufA_pong[24],wbufA_pong[24],outbuf_pong[24]);
					fun_dw1(dbufA_pong[25],wbufA_pong[25],outbuf_pong[25]);
					fun_dw1(dbufA_pong[26],wbufA_pong[26],outbuf_pong[26]);
					fun_dw1(dbufA_pong[27],wbufA_pong[27],outbuf_pong[27]);
					fun_dw1(dbufA_pong[28],wbufA_pong[28],outbuf_pong[28]);
					fun_dw1(dbufA_pong[29],wbufA_pong[29],outbuf_pong[29]);
					fun_dw1(dbufA_pong[30],wbufA_pong[30],outbuf_pong[30]);
					fun_dw1(dbufA_pong[31],wbufA_pong[31],outbuf_pong[31]);							

					loop_d12:for(int x=0;x<1;x++)
					{			
							write_off(output_data1, output_data2, output_data3, output_data4, outbuf_ping, kchoy, ch);																								
							kchoy = kchoy + 4;																														
					}
					loop_e12:for(int y=0;y<1;y++)
					{			
							read_data(dbufA_ping, input_data1, input_data2, input_data3, input_data4, kchdy, ch);
							read_wts(wbufA_ping, conv9_dw1, conv9_dw2, conv9_dw3, conv9_dw4, kchiny1, ch);
							kchiny1 = kchiny1 + 8;
							kchdy = kchdy + 4;
					}
			}									
		}							
}
}

