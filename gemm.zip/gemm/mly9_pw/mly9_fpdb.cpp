#include<stdio.h>
#include "math.h"
#include "datatype.h"

void write_off(T16 *out1,T16 *out2, T16 *out3, T16 *out4, T16 (*out_buf)[64],int kcho, int ch)
{	
	if(ch > 0)
	{					loop_c13a:for(int x=0;x<7;x++)	
						{
							loop_c13:for (int cho = 0; cho < 64; cho=cho+4)
							{
										*(out1 + kcho)     = out_buf[x][cho];
										*(out2 + kcho + 1) = out_buf[x][cho+1];
										*(out3 + kcho + 2) = out_buf[x][cho+2];
										*(out4 + kcho + 3) = out_buf[x][cho+3];
										kcho = kcho + 4;
							}	
						}
	}
}

void read_data(T16 (*in_buf)[32], T16 *inp1, T16 *inp2, T16 *inp3, T16 *inp4,int kchd, int ch)
{
						if(ch < 31)
						{		
												loop_c6a:for(int x=0;x<7;x++)
												{
													loop_c6: for(int ch_inp=0;ch_inp<32;ch_inp = ch_inp+4)
													{
																in_buf[x][ch_inp  ] = *(inp1 +  (ch_inp    ) + kchd);				
																in_buf[x][ch_inp+1] = *(inp2 +  (ch_inp + 1) + kchd + 1);	
																in_buf[x][ch_inp+2] = *(inp3 +  (ch_inp + 2) + kchd + 2);	
																in_buf[x][ch_inp+3] = *(inp4 +  (ch_inp + 3) + kchd + 3);
																kchd = kchd+4;	
													}	
												}
						}
}

void read_wts(T16 (*wt_buf)[64], T16 *inpwt1, T16 *inpwt2, T16 *inpwt3, T16 *inpwt4, int kch, int ch)
{
						if(ch < 31)
						{	
													loop_c9: for(int ch_inp=0; ch_inp<64 ;ch_inp = ch_inp+4)
													{			
														loop_c10:for (int x = 0; x < 32; x++)
														{
																wt_buf[x][ch_inp  ] = *(inpwt1 + kch);												
																wt_buf[x][ch_inp+1] = *(inpwt2 + kch + 1);												
																wt_buf[x][ch_inp+2] = *(inpwt3 + kch + 2);												
																wt_buf[x][ch_inp+3] = *(inpwt4 + kch + 3);
																kch = kch + 8 ;																								
														}		
													}	
						}
}

/*
void fun_dw1(T16 inp[9][9] , T16 cvw[3][3], T16 out[7][7], T16 bgammax, T16 bbetax, T16 bmeanx, T16 bvarx)
{
    label1:for (int j = 0; j < 7; j++) {
    	label2:for (int m = 0; m < 7; m++) {
    		T16 out_temp = 0;
    		label3:for (int x = 0; x < 3; x++) {
    			label4:for (int y = 0; y < 3; y++) {
                	out_temp += inp[j + x][m + y] * cvw[x][y];
                	//out_temp = inp[j + x][m + y]; // * cvw[x][y];
                }
            }
				T16 normalized_value = (out_temp - bmeanx) / sqrt(bvarx+1e-3);
				T16 scaled_value = bgammax * normalized_value + bbetax;
				if(scaled_value < 0.0)
				{
					out[j][m]= 0.0;
				}
				else if(scaled_value > 6.0)
				{
					out[j][m]= 6.0;
				}
				else
				{
					out[j][m]=scaled_value;
				}            
        }
    }
}
*/

void fun_mul(T16 (*A)[32], T16 (*B)[64], T16 (*temp)[64])
{
    loop_mul1:for (int i = 0; i < 7; ++i) {
        loop_mul2:for (int j = 0; j < 64; ++j) {
            loop_mul3:for (int k = 0; k < 32; ++k) {
                temp[i][j] += A[i][k] * B[k][j];
            }
        }
    }	
}
/*
void fun_mul(T16 (*A)[32], T16 (*B)[64], T16 (*temp)[64])
{
  loop_mul1: for (int i = 0; i < 7; ++i) {
    //#pragma HLS PIPELINE II=1
    #pragma HLS UNROLL factor=2
	
    loop_mul2: for (int j = 0; j < 64; ++j) {
      //#pragma HLS PIPELINE II=1
      #pragma HLS UNROLL factor=8
      loop_mul3: for (int k = 0; k < 32; ++k) {
        temp[i][j] += A[i][k] * B[k][j];
      }
    }
  }
}
*/

/*
void fun_pw1(T16 (*inp2)[7][7], int length, T16 (*cvw2), T16 (*out2)[7][7], int length0)
{
    label8: for (int r = 0; r < 7; r++) {
        label9: for (int c = 0; c < 7; c++) {
            label10: for (int cho = 0; cho < length0; cho++) {
                label11: for (int chi = 0; chi < length; chi++) {
                    out2[cho][r][c] += inp2[chi][r][c] * cvw2[cho * length + chi];
                }
            }
        }
    }
}

void fun_bn2(T16 (*inp1)[7][7], T16 (*bgammax), T16 (*bbetax), T16 (*bmeanx), T16 (*bvarx), T16 (*out)[7][7])
{
	label12:for(int cho=0;cho<64;cho++){
		T16 scaled_value;
		label3:for(int r=0;r<7;r++){
			label14:for(int c=0;c<7;c++){
				
					T16 normalized_value = (inp1[cho][r][c] - bmeanx[cho]) / sqrt(bvarx[cho]+1e-3);
					scaled_value = bgammax[cho] * normalized_value + bbetax[cho];
				
				if(scaled_value < 0.0)
				{
					out[cho][r][c]= 0.0;
				}
				else if(scaled_value > 6.0)
				{
					out[cho][r][c]= 6.0;
				}
				else
				{
					out[cho][r][c]=scaled_value;
				}
			}
		}
	}
}
*/
void  mly9_fpdb(
    T16 *conv9_s1pw1,
    T16 *conv9_s1pw2,
    T16 *conv9_s1pw3,
    T16 *conv9_s1pw4,
	T16 *input_data1,
	T16 *input_data2,
	T16 *input_data3,
	T16 *input_data4,
    T16 *output_data1,
    T16 *output_data2,
    T16 *output_data3,
    T16 *output_data4
)

{
#pragma HLS INTERFACE m_axi depth=1024 port=conv9_s1pw1 offset=slave bundle=wtw1
#pragma HLS INTERFACE s_axilite port=conv9_s1pw1
#pragma HLS INTERFACE m_axi depth=1024 port=conv9_s1pw2 offset=slave bundle=wtw2
#pragma HLS INTERFACE s_axilite port=conv9_s1pw2
#pragma HLS INTERFACE m_axi depth=1024 port=conv9_s1pw3 offset=slave bundle=wtw3
#pragma HLS INTERFACE s_axilite port=conv9_s1pw3
#pragma HLS INTERFACE m_axi depth=1024 port=conv9_s1pw4 offset=slave bundle=wtw4
#pragma HLS INTERFACE s_axilite port=conv9_s1pw4

#pragma HLS INTERFACE m_axi depth=1024 port=input_data1 offset=slave bundle=input1
#pragma HLS INTERFACE s_axilite port=input_data1
#pragma HLS INTERFACE m_axi depth=1024 port=input_data2 offset=slave bundle=input2
#pragma HLS INTERFACE s_axilite port=input_data2
#pragma HLS INTERFACE m_axi depth=1024 port=input_data3 offset=slave bundle=input3
#pragma HLS INTERFACE s_axilite port=input_data3
#pragma HLS INTERFACE m_axi depth=1024 port=input_data4 offset=slave bundle=input4
#pragma HLS INTERFACE s_axilite port=input_data4

#pragma HLS INTERFACE m_axi depth=1024 port=output_data1 offset=slave bundle=output1
#pragma HLS INTERFACE s_axilite port=output_data1
#pragma HLS INTERFACE m_axi depth=1024 port=output_data2 offset=slave bundle=output2
#pragma HLS INTERFACE s_axilite port=output_data2
#pragma HLS INTERFACE m_axi depth=1024 port=output_data3 offset=slave bundle=output3
#pragma HLS INTERFACE s_axilite port=output_data3
#pragma HLS INTERFACE m_axi depth=1024 port=output_data4 offset=slave bundle=output4
#pragma HLS INTERFACE s_axilite port=output_data4
#pragma HLS INTERFACE s_axilite port=return

#include "D:\\mobilenet\\mobly9_act\\conv9d_1.txt"
#include "D:\\mobilenet\\mobly9_act\\conv9d_2.txt"
#include "D:\\mobilenet\\mobly9_act\\conv9d_3.txt"
#include "D:\\mobilenet\\mobly9_act\\conv9d_4.txt"

#pragma HLS array_partition variable=gamma complete dim=0
#pragma HLS array_partition variable=beta complete dim=0
#pragma HLS array_partition variable=batch_mean complete dim=0
#pragma HLS array_partition variable=batch_variance complete dim=0

#include "D:\\mobilenet\\mobly9_act\\conv9p_1.txt"
#include "D:\\mobilenet\\mobly9_act\\conv9p_2.txt"
#include "D:\\mobilenet\\mobly9_act\\conv9p_3.txt"
#include "D:\\mobilenet\\mobly9_act\\conv9p_4.txt"

#pragma HLS array_partition variable=gamma1 complete dim=0
#pragma HLS array_partition variable=beta1 complete dim=0
#pragma HLS array_partition variable=batch_mean1 complete dim=0
#pragma HLS array_partition variable=batch_variance1 complete dim=0

    T16 dbufA_ping[7][32];
    T16 dbufA_pong[7][32];
	//#pragma HLS array_partition variable=dbufA_ping cyclic factor=7 dim=1
	//#pragma HLS array_partition variable=dbufA_pong cyclic factor=7 dim=1    
	//#pragma HLS array_partition variable=dbufA_ping cyclic factor=4 dim=2
	//#pragma HLS array_partition variable=dbufA_pong cyclic factor=4 dim=2
	//#pragma HLS array_partition variable=dbufA_ping complete dim=0
	//#pragma HLS array_partition variable=dbufA_pong complete dim=0
    T16 wbufA_ping[32][64];
    T16 wbufA_pong[32][64];
    //#pragma HLS array_partition variable=wbufA_ping cyclic factor=64 dim=1
	//#pragma HLS array_partition variable=wbufA_pong cyclic factor=64 dim=1   
	//#pragma HLS array_partition variable=wbufA_ping cyclic factor=4 dim=2
	//#pragma HLS array_partition variable=wbufA_pong cyclic factor=4 dim=2    
	//#pragma HLS array_partition variable=wbufA_ping complete dim=0
	//#pragma HLS array_partition variable=wbufA_pong complete dim=0
    T16 outbuf_ping[7][64];
    T16 outbuf_pong[7][64];
	//#pragma HLS array_partition variable=outbuf_ping cyclic factor=32 dim=1
	//#pragma HLS array_partition variable=outbuf_pong cyclic factor=32 dim=1    
	//#pragma HLS array_partition variable=outbuf_ping complete dim=0
	//#pragma HLS array_partition variable=outbuf_pong complete dim=0
	
	T16 temp_ping[7][64]={0};
	
	T16 temp_pong[7][64]={0};

    int OFFCHIP_WIDTH=9;
    int OFFCHIP_WIDTH1=7;
    int kchinx1=0;
    int kchiny1=0;
    int kchin2=0;
    int ch_inp = 0;
    int k=0;
    int kchdx1 = 0;
    int kchdy1 = 0;
    int kchox1 = 0;
    int kchoy1 = 0;
    	

							read_data(dbufA_ping, input_data1, input_data2, input_data3, input_data4,kchdx1 ,0);
							read_wts(wbufA_ping, conv9_s1pw1, conv9_s1pw2, conv9_s1pw3, conv9_s1pw4, kchiny1,0);	
							kchiny1 = kchiny1+4 ;		
							kchdx1 = kchdx1 + 4;							
															

	loop_sets:for(int set=0; set<16; set++)  // for each set, 64 output feature maps are generated.
	{
    	loop_tiles:for(int tileIndex=0;tileIndex<7;tileIndex++)  // 7x7 = 49 slides are required to cover complete feature map.
    	{ 	
    		//#pragma HLS PIPELINE II=1 
			if(tileIndex %2 == 0)
			{			
				loop_dep1:for (int ch = 0; ch < 32; ch++)  //1024/32=32 , here depth is covered.
				{
					//#pragma HLS DEPENDENCE variable=temp_ping inter false					
					//#pragma HLS DEPENDENCE variable=temp_pong inter false
					if( ch % 2 == 0 )
					{		
						fun_mul(dbufA_ping, wbufA_ping, temp_ping);

						loop_e1:for(int y=0;y<1;y++)
						{		
							read_data(dbufA_pong, input_data1, input_data2, input_data3, input_data4,kchdx1 , ch);
							read_wts(wbufA_pong, conv9_s1pw1, conv9_s1pw2, conv9_s1pw3, conv9_s1pw4, kchinx1, ch);
							kchinx1 = kchinx1 + 8;
							kchdx1 = kchdx1 + 8;
						}				
					}	
					else if( ch % 2 == 1 )
					{			
						fun_mul(dbufA_pong, wbufA_pong, temp_ping);								
				
						loop_e12:for(int y=0;y<1;y++)
						{			
							read_data(dbufA_ping, input_data1, input_data2, input_data3, input_data4,kchdy1 , ch);
							read_wts(wbufA_ping, conv9_s1pw1, conv9_s1pw2, conv9_s1pw3, conv9_s1pw4, kchiny1, ch);
							kchiny1 = kchiny1 + 8;
							kchdy1 = kchdy1 + 8;
						}
					}
				}
				loop_d12a:for(int y=0;y<1;y++)
				{	
					loop_d12b:for(int ti=0;ti<7;ti++)
					{
						loop_d12c:for(int x=0;x<64;x++)
						{
							outbuf_ping[ti][x]  =  temp_pong[ti][x];	
							temp_pong[ti][x] = 0;
						}
					}				
					write_off(output_data1, output_data2, output_data3, output_data4, outbuf_pong,kchox1 , tileIndex);	
					kchox1 = kchox1 + 8;    																					
				}				
			}
			else if(tileIndex %2 == 1)
			{				
				l2oop_y1:for (int ch = 0; ch < 32; ch++)  //1024/32=32 , here depth is covered.
				{
					//#pragma HLS DEPENDENCE variable=temp_ping inter false					
					//#pragma HLS DEPENDENCE variable=temp_pong inter false					
					if( ch % 2 == 0 )
					{										
						fun_mul(dbufA_ping,wbufA_ping,temp_pong);																			
						l2oop_y2:for(int y=0;y<1;y++)
						{		
							read_data(dbufA_pong, input_data1, input_data2, input_data3, input_data4,kchdx1 , ch);
							read_wts(wbufA_pong, conv9_s1pw1, conv9_s1pw2, conv9_s1pw3, conv9_s1pw4, kchinx1, ch);
							kchinx1 = kchinx1 + 8;
							kchdx1 = kchdx1 + 8;
						}				
					}	
					else if( ch % 2 == 1 )
					{			
						fun_mul(dbufA_pong,wbufA_pong,temp_pong);												

						l2oop_y3:for(int y=0;y<1;y++)
						{			
							read_data(dbufA_ping, input_data1, input_data2, input_data3, input_data4,kchdy1 , ch);
							read_wts(wbufA_ping, conv9_s1pw1, conv9_s1pw2, conv9_s1pw3, conv9_s1pw4, kchiny1, ch);
							kchiny1 = kchiny1 + 8;
							kchdy1 = kchdy1 + 8;
						}
					}
				}	
				l2oop_y4:for(int y=0;y<1;y++)
				{	
					l2oop_y5:for(int ti=0;ti<7;ti++)
					{
						l2oop_y6:for(int x=0;x<64;x++)
						{
							outbuf_pong[ti][x]  =  temp_ping[ti][x];								
							temp_ping[ti][x] = 0;
						}
					}
					write_off(output_data1, output_data2, output_data3, output_data4, outbuf_ping,kchoy1 , tileIndex);	
					kchoy1 = kchoy1 + 8;																													
				}															
			}																																			
    	}
	}
}



