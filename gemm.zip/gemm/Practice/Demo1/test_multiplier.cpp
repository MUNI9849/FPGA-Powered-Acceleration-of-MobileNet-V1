#include <stdio.h>
unsigned int hls_multiplier(unsigned short int a, unsigned short int b);
int main() {
unsigned short int a, b,c;
unsigned short int p;
a = 5;
b = 7;
p=0;
printf("initialized variables: a=%d, b=%d, p=%d \n", a, b, p);
p = hls_multiplier(a, b);
printf("testing hls_multiplier: %d * %d = %d \n", a, b, p);
return 0;
}
