unsigned int hls_multiplier(unsigned short int a, unsigned short int b) {

#pragma HLS INTERFACe s_axilite port=return bundle=CRTLS
#pragma HLS INTERFACe s_axilite port=a bundle=CRTLS
#pragma HLS INTERFACe s_axilite port=b bundle=CRTLS

unsigned int p;
p = a * b;
return p;
}
