#include <stdio.h>
void hls_mul(float *a, float *b, float *c);
int main() 
{
float a[20], b[20],c[20];
for(int i=0;i<20;i++)
{
	a[i] = i;
	b[i] = i+2;
	c[i] = 0;
}

printf("Hello, we are here \n");
hls_mul(a, b,c);

for(int i=0;i<20;i++)
{
	printf("the output is %f \n",c[i]);
}


return 0;
}
