#include<stdio.h>
#include "math.h"
#include "datatype.h"

void write_off(T16 *out1,T16 *out2, T16 *out3, T16 *out4, T16 (*out_buf)[49],int kcho, int ch)
{	
	if(ch > 0)
	{		
							loop_wr1:for(int x=0;x<49;x++)
							{
									loop_wr3: for(int p=0;p<32;p=p+4)
									{
										*(out1 + kcho)     = out_buf[p   ][x];
										*(out2 + kcho + 1) = out_buf[p + 1][x]; 
										*(out3 + kcho + 2) = out_buf[p + 2][x];
										*(out4 + kcho + 3) = out_buf[p + 3][x];
										kcho = kcho + 4;
									}
							}
	}
}

void read_data(T16 (*in_buf)[49], T16 *inp1, T16 *inp2, T16 *inp3, T16 *inp4,int kchd, int ch)
{
						if(ch < 31)
						{		

							loop_rd1:for(int x=0;x<49;x++)
							{
									loop_rd3: for(int p=0;p<32;p=p+4)
									{										
										in_buf[p  ][x] 	= *(inp1 + kchd);									
										in_buf[p + 1][x] = *(inp2 + kchd + 1);	
										in_buf[p + 2][x] = *(inp3 + kchd + 2);	
										in_buf[p + 3][x] = *(inp4 + kchd + 3);	
										kchd = kchd +4;
									}
							}
						}
}

void read_pts(T16 gamma1[32], T16 beta1[32], T16 mean1[32], T16 var1[32], T16 *gamma, T16 *beta, T16 *mean, T16 *var, int kch, int ch)
{
						if(ch < 31)
						{	
													loop_rdpts: for(int ch_inp=0; ch_inp<32 ;ch_inp++)
													{			
																gamma1[ch_inp] 	= *(gamma + kch);												
																beta1[ch_inp] 	= *(beta  + kch);												
																mean1[ch_inp] 	= *(mean  + kch);												
																var1[ch_inp] 	= *(var   + kch);
																kch = kch + 1 ;																							
													}	
						}
}

/*
void fun_bn2(T16 (*inp1)[7][7], T16 (*bgammax), T16 (*bbetax), T16 (*bmeanx), T16 (*bvarx), T16 (*out)[7][7])
{
	T16 temp = 1e-3;
	//T16 temp1 = 100;
	label12:for(int cho=0;cho<32;cho++){
		T16 scaled_value;
		label3:for(int r=0;r<7;r++){
			label14:for(int c=0;c<7;c++){
				
					T16 normalized_value = (inp1[cho][r][c] - bmeanx[cho]) / (T16)sqrtf(bvarx[cho]+temp);
					//T16 normalized_value = temp1 / (T16)sqrtf(bvarx[cho]+temp);
					scaled_value = bgammax[cho] * normalized_value + bbetax[cho];
				
				if(scaled_value < 0.0)
				{
					out[cho][r][c]= 0.0;
				}
				else if(scaled_value > 6.0)
				{
					out[cho][r][c]= 6.0;
				}
				else
				{
					out[cho][r][c]=scaled_value;
				}
			}
		}
	}
}
*/
void fun_bn2(T16 (*inp1)[49], T16 (*bgammax), T16 (*bbetax), T16 (*bmeanx), T16 (*bvarx), T16 (*out)[49])
{
	T16 temp = 1e-3;
	//T16 temp1 = 100;
	T16 tx1;
	T16 tx2[49];
	T16 tx3[49];
	T16 normalized_value[49];
	T16 scaled_value[49];
	label12:for(int cho=0;cho<32;cho++){		
		tx1 = (T16)sqrtf(bvarx[cho]+temp);
		label3:for(int r=0;r<49;r++){
					tx2[r] = inp1[cho][r] - bmeanx[cho];
					normalized_value[r] = tx2[r] / tx1;
					tx3[r] = bgammax[cho] * normalized_value[r];
					//T16 normalized_value = temp1 / (T16)sqrtf(bvarx[cho]+temp);
					scaled_value[r] =  tx3[r] + bbetax[cho];
				
				if(scaled_value[r] < 0.0)
				{
					out[cho][r]= 0.0;
				}
				else if(scaled_value[r] > 6.0)
				{
					out[cho][r]= 6.0;
				}
				else
				{
					out[cho][r]=scaled_value[r];
				}
			}
	}
}


void  mly9_fbn2(
	T16 *input_data1,
	T16 *input_data2,
	T16 *input_data3,
	T16 *input_data4,
	T16 *gamma,
	T16 *beta,
	T16 *mean,
	T16 *var,
    T16 *output_data1,
    T16 *output_data2,
    T16 *output_data3,
    T16 *output_data4
)
{
#pragma HLS INTERFACE m_axi depth=1024 port=input_data1 offset=slave bundle=input1
#pragma HLS INTERFACE s_axilite port=input_data1
#pragma HLS INTERFACE m_axi depth=1024 port=input_data2 offset=slave bundle=input2
#pragma HLS INTERFACE s_axilite port=input_data2
#pragma HLS INTERFACE m_axi depth=1024 port=input_data3 offset=slave bundle=input3
#pragma HLS INTERFACE s_axilite port=input_data3
#pragma HLS INTERFACE m_axi depth=1024 port=input_data4 offset=slave bundle=input4
#pragma HLS INTERFACE s_axilite port=input_data4
	
	
#pragma HLS INTERFACE m_axi depth=1024 port=gamma offset=slave bundle=pgamma
#pragma HLS INTERFACE s_axilite port=gamma
#pragma HLS INTERFACE m_axi depth=1024 port=beta offset=slave bundle=pbeta
#pragma HLS INTERFACE s_axilite port=beta
#pragma HLS INTERFACE m_axi depth=1024 port=mean offset=slave bundle=pmean
#pragma HLS INTERFACE s_axilite port=mean
#pragma HLS INTERFACE m_axi depth=1024 port=var offset=slave bundle=pvar
#pragma HLS INTERFACE s_axilite port=var


#pragma HLS INTERFACE m_axi depth=1024 port=output_data1 offset=slave bundle=output1
#pragma HLS INTERFACE s_axilite port=output_data1
#pragma HLS INTERFACE m_axi depth=1024 port=output_data2 offset=slave bundle=output2
#pragma HLS INTERFACE s_axilite port=output_data2
#pragma HLS INTERFACE m_axi depth=1024 port=output_data3 offset=slave bundle=output3
#pragma HLS INTERFACE s_axilite port=output_data3
#pragma HLS INTERFACE m_axi depth=1024 port=output_data4 offset=slave bundle=output4
#pragma HLS INTERFACE s_axilite port=output_data4
#pragma HLS INTERFACE s_axilite port=return

	T16 gamma1_ping[32];
	#pragma HLS array_partition variable=gamma1_ping cyclic factor=1 dim=1
	T16 beta1_ping[32];
	#pragma HLS array_partition variable=beta1_ping cyclic factor=1 dim=1
	T16 batch_mean1_ping[32];
	#pragma HLS array_partition variable=batch_mean1_ping cyclic factor=1 dim=1
	T16 batch_variance1_ping[32];
	#pragma HLS array_partition variable=batch_variance1_ping cyclic factor=1 dim=1
	T16 gamma1_pong[32];
	#pragma HLS array_partition variable=gamma1_pong cyclic factor=1 dim=1
	T16 beta1_pong[32];
	#pragma HLS array_partition variable=beta1_pong cyclic factor=1 dim=1
	T16 batch_mean1_pong[32];
	#pragma HLS array_partition variable=batch_mean1_pong cyclic factor=1 dim=1
	T16 batch_variance1_pong[32];
	#pragma HLS array_partition variable=batch_variance1_pong cyclic factor=1 dim=1
	
    T16 dbufA_ping[32][49];
    T16 dbufA_pong[32][49];
	#pragma HLS array_partition variable=dbufA_ping cyclic factor=4 dim=1
	#pragma HLS array_partition variable=dbufA_pong cyclic factor=4 dim=1    
	//#pragma HLS array_partition variable=dbufA_ping cyclic factor=4 dim=2
	//#pragma HLS array_partition variable=dbufA_pong cyclic factor=4 dim=2
	//#pragma HLS array_partition variable=dbufA_ping complete dim=0
	//#pragma HLS array_partition variable=dbufA_pong complete dim=0
    T16 outbuf_ping[32][49];
    T16 outbuf_pong[32][49];
	#pragma HLS array_partition variable=outbuf_ping cyclic factor=4 dim=1
	#pragma HLS array_partition variable=outbuf_pong cyclic factor=4 dim=1    
	//#pragma HLS array_partition variable=outbuf_ping complete dim=0
	//#pragma HLS array_partition variable=outbuf_pong complete dim=0
	

    int OFFCHIP_WIDTH=9;
    int OFFCHIP_WIDTH1=7;
    int kchinx1=0;
    int kchiny1=0;
    int kchin2=0;
    int ch_inp = 0;
    int k=0;
    int kchdx1 = 0;
    int kchdy1 = 0;
    int kchox1 = 0;
    int kchoy1 = 0;

							read_data(dbufA_ping, input_data1, input_data2, input_data3, input_data4,kchdx1 ,0);
							//read_para(gamma1[0] ,beta1[0] ,batch_mean1[0] ,batch_variance1[0] ,gamma ,beta ,mean ,var);
							read_pts(gamma1_ping, beta1_ping, batch_mean1_ping, batch_variance1_ping, gamma, beta, mean, var, kchinx1, 0);	
							kchinx1 = kchinx1+32;		
							kchdx1 = kchdx1 + 4;							
				//#pragma HLS parallel	
			loop_tile: for(int tx=0;tx<1;tx++)
			{
				loop_dep1:for (int ch = 0; ch < 32; ch++)  //1024/32=32 , here depth is covered.
				{
					if( ch % 2 == 0 )
					{	
						loop_ct1:for(int p=0;p<1;p++)
						{
							fun_bn2(dbufA_ping, gamma1_ping, beta1_ping, batch_mean1_ping, batch_variance1_ping, outbuf_ping);
						}						
						loop_ct2:for(int z=0;z<1;z++)
						{								
								write_off(output_data1, output_data2, output_data3, output_data4, outbuf_pong, kchox1, ch);
								kchox1 = kchox1 + 4;
						}
						
						loop_e1:for(int y=0;y<1;y++)
						{		
								read_data(dbufA_pong, input_data1, input_data2, input_data3, input_data4,kchdx1 , ch);
								read_pts(gamma1_pong, beta1_pong, batch_mean1_pong, batch_variance1_pong, gamma, beta, mean, var, kchinx1, ch);
								kchinx1 = kchinx1+32;		
								kchdx1 = kchdx1 + 4;										
						}				
					}	
					else if( ch % 2 == 1 )
					{			
						loop_ct3:for(int p=0;p<1;p++)
						{					
							fun_bn2(dbufA_pong, gamma1_pong, beta1_pong, batch_mean1_pong, batch_variance1_pong, outbuf_pong);
						}						
						loop_ct4:for(int z=0;z<1;z++)
						{
								write_off(output_data1, output_data2, output_data3, output_data4, outbuf_ping, kchoy1, ch);
								kchoy1 = kchoy1 + 4;
						}												
						loop_e12:for(int y=0;y<1;y++)
						{			
								read_data(dbufA_ping, input_data1, input_data2, input_data3, input_data4,kchdy1 , ch);					
								read_pts(gamma1_ping, beta1_ping, batch_mean1_ping, batch_variance1_ping, gamma, beta, mean, var, kchiny1, ch);			
								kchiny1 = kchiny1+32;		
								kchdy1 = kchdy1 + 4;														
						}
					}
				}	
			}
}



