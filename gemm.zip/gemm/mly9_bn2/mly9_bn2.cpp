#include<stdio.h>
#include "math.h"

void write_off(float *out1,float *out2, float *out3, float *out4, float (*out_buf)[7][7],int kcho, int ch)
{	
	if(ch > 0)
	{		
							loop_c6a:for(int x=0;x<7;x++)
							{
								loop_c6: for(int y=0; y<7; y++)
								{	
									loop_top1: for(int p=0;p<64;p=p+4)
									{
										*(out1 + kcho)     = out_buf[p   ][7][7];
										*(out2 + kcho + 1) = out_buf[p + 1][7][7]; 
										*(out3 + kcho + 2) = out_buf[p + 2][7][7];
										*(out4 + kcho + 3) = out_buf[p + 3][7][7];
										kcho = kcho + 4;
									}
								}
							}
	}
}

void read_data(float (*in_buf)[7][7], float *inp1, float *inp2, float *inp3, float *inp4,int kchd, int ch)
{
						if(ch < 31)
						{		

							loop_c6a:for(int x=0;x<7;x++)
							{
								loop_c6: for(int y=0; y<7; y++)
								{	
									loop_top1: for(int p=0;p<32;p=p+4)
									{										
										in_buf[p  ][x][y] 	= *(inp1 + kchd);									
										in_buf[p + 1][x][y] = *(inp2 + kchd + 1);	
										in_buf[p + 2][x][y] = *(inp3 + kchd + 2);	
										in_buf[p + 3][x][y] = *(inp4 + kchd + 3);	
										kchd = kchd +4;
									}
								}
							}
						}
}

void read_pts(float gamma1[32], float beta1[32], float mean1[32], float var1[32], float *gamma, float *beta, float *mean, float *var, int kch, int ch)
{
						if(ch < 31)
						{	
													loop_c9: for(int ch_inp=0; ch_inp<32 ;ch_inp++)
													{			
																gamma1[ch_inp] 	= *(gamma + kch);												
																beta1[ch_inp] 	= *(beta  + kch);												
																mean1[ch_inp] 	= *(mean  + kch);												
																var1[ch_inp] 	= *(var   + kch);
																kch = kch + 1 ;																							
													}	
						}
}


void fun_bn2(float (*inp1)[7][7], float (*bgammax), float (*bbetax), float (*bmeanx), float (*bvarx), float (*out)[7][7])
{
	label12:for(int cho=0;cho<32;cho++){
		float scaled_value;
		label3:for(int r=0;r<7;r++){
			label14:for(int c=0;c<7;c++){
				
					float normalized_value = (inp1[cho][r][c] - bmeanx[cho]) / sqrt(bvarx[cho]+1e-3);
					scaled_value = bgammax[cho] * normalized_value + bbetax[cho];
				
				if(scaled_value < 0.0)
				{
					out[cho][r][c]= 0.0;
				}
				else if(scaled_value > 6.0)
				{
					out[cho][r][c]= 6.0;
				}
				else
				{
					out[cho][r][c]=scaled_value;
				}
			}
		}
	}
}

void  mly9_bn2(
	float *input_data1,
	float *input_data2,
	float *input_data3,
	float *input_data4,
	float *gamma,
	float *beta,
	float *mean,
	float *var,
    float *output_data1,
    float *output_data2,
    float *output_data3,
    float *output_data4
)
{
#pragma HLS INTERFACE m_axi depth=1024 port=input_data1 offset=slave bundle=input1
#pragma HLS INTERFACE s_axilite port=input_data1
#pragma HLS INTERFACE m_axi depth=1024 port=input_data2 offset=slave bundle=input2
#pragma HLS INTERFACE s_axilite port=input_data2
#pragma HLS INTERFACE m_axi depth=1024 port=input_data3 offset=slave bundle=input3
#pragma HLS INTERFACE s_axilite port=input_data3
#pragma HLS INTERFACE m_axi depth=1024 port=input_data4 offset=slave bundle=input4
#pragma HLS INTERFACE s_axilite port=input_data4
	
	
#pragma HLS INTERFACE m_axi depth=1024 port=gamma offset=slave bundle=pgamma
#pragma HLS INTERFACE s_axilite port=gamma
#pragma HLS INTERFACE m_axi depth=1024 port=beta offset=slave bundle=pbeta
#pragma HLS INTERFACE s_axilite port=beta
#pragma HLS INTERFACE m_axi depth=1024 port=mean offset=slave bundle=pmean
#pragma HLS INTERFACE s_axilite port=mean
#pragma HLS INTERFACE m_axi depth=1024 port=var offset=slave bundle=pvar
#pragma HLS INTERFACE s_axilite port=var


#pragma HLS INTERFACE m_axi depth=1024 port=output_data1 offset=slave bundle=output1
#pragma HLS INTERFACE s_axilite port=output_data1
#pragma HLS INTERFACE m_axi depth=1024 port=output_data2 offset=slave bundle=output2
#pragma HLS INTERFACE s_axilite port=output_data2
#pragma HLS INTERFACE m_axi depth=1024 port=output_data3 offset=slave bundle=output3
#pragma HLS INTERFACE s_axilite port=output_data3
#pragma HLS INTERFACE m_axi depth=1024 port=output_data4 offset=slave bundle=output4
#pragma HLS INTERFACE s_axilite port=output_data4
#pragma HLS INTERFACE s_axilite port=return

	float gamma1_ping[64];
	float beta1_ping[64];
	float batch_mean1_ping[64];
	float batch_variance1_ping[64];
	float gamma1_pong[64];
	float beta1_pong[64];
	float batch_mean1_pong[64];
	float batch_variance1_pong[64];
	
    float dbufA_ping[64][7][7];
    float dbufA_pong[64][7][7];
	//#pragma HLS array_partition variable=dbufA_ping cyclic factor=7 dim=1
	//#pragma HLS array_partition variable=dbufA_pong cyclic factor=7 dim=1    
	//#pragma HLS array_partition variable=dbufA_ping cyclic factor=4 dim=2
	//#pragma HLS array_partition variable=dbufA_pong cyclic factor=4 dim=2
	//#pragma HLS array_partition variable=dbufA_ping complete dim=0
	//#pragma HLS array_partition variable=dbufA_pong complete dim=0
    float outbuf_ping[64][7][7];
    float outbuf_pong[64][7][7];
	//#pragma HLS array_partition variable=outbuf_ping cyclic factor=7 dim=1
	//#pragma HLS array_partition variable=outbuf_pong cyclic factor=7 dim=1    
	//#pragma HLS array_partition variable=outbuf_ping complete dim=0
	//#pragma HLS array_partition variable=outbuf_pong complete dim=0
	

    int OFFCHIP_WIDTH=9;
    int OFFCHIP_WIDTH1=7;
    int kchinx1=0;
    int kchiny1=0;
    int kchin2=0;
    int ch_inp = 0;
    int k=0;
    int kchdx1 = 0;
    int kchdy1 = 0;
    int kchox1 = 0;
    int kchoy1 = 0;

							read_data(dbufA_ping, input_data1, input_data2, input_data3, input_data4,kchdx1 ,0);
							//read_para(gamma1[0] ,beta1[0] ,batch_mean1[0] ,batch_variance1[0] ,gamma ,beta ,mean ,var);
							read_pts(gamma1_ping, beta1_ping, batch_mean1_ping, batch_variance1_ping, gamma, beta, mean, var, kchiny1, 0);	
							kchiny1 = kchiny1+64;		
							kchdx1 = kchdx1 + 4;							
																						
				loop_dep1:for (int ch = 0; ch < 16; ch++)  //1024/64=16 , here depth is covered.
				{
					if( ch % 2 == 0 )
					{	
						fun_bn2(dbufA_ping, gamma1_ping, beta1_ping, batch_mean1_ping, batch_variance1_ping, outbuf_ping);
						
						for(int z=0;z<1;z++)
						{
							write_off(output_data1, output_data2, output_data3, output_data4, outbuf_pong, kchox1, ch);
						}
						
						loop_e1:for(int y=0;y<1;y++)
						{		
							read_data(dbufA_pong, input_data1, input_data2, input_data3, input_data4,kchdx1 , ch);
							read_pts(gamma1_pong, beta1_pong, batch_mean1_pong, batch_variance1_pong, gamma, beta, mean, var, kchinx1, ch);
							kchinx1 = kchinx1 + 64;
							kchdx1 = kchdx1 + 8;
						}				
					}	
					else if( ch % 2 == 1 )
					{			
						fun_bn2(dbufA_pong, gamma1_pong, beta1_pong, batch_mean1_pong, batch_variance1_pong, outbuf_pong);
						
						for(int z=0;z<1;z++)
						{
							write_off(output_data1, output_data2, output_data3, output_data4, outbuf_ping, kchox1, ch);
						}								
				
						loop_e12:for(int y=0;y<1;y++)
						{			
							read_data(dbufA_ping, input_data1, input_data2, input_data3, input_data4,kchdy1 , ch);
							read_pts(gamma1_ping, beta1_ping, batch_mean1_ping, batch_variance1_ping, gamma, beta, mean, var, kchiny1, ch);							
							kchiny1 = kchiny1 + 64;
							kchdy1 = kchdy1 + 8;
						}
					}
				}			
}



