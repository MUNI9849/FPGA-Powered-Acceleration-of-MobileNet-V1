#include<stdio.h>
#include "math.h"
#include "datatype.h"



void write_off(T16 *out1, T16 out_buf[100][100][100],int kcho)
{							
						if(kcho > 0)
						{
							int ct = 0;
							loop_c6a1:for(int x=0;x<100;x++)
							{
								loop_c6a2: for(int y=0;y<100;y++)
								{
									loop_c6a3: for(int z=0;z<100;z++)
									{
										*(out1 + (kcho*100) + ct) = out_buf[x][y][z];	
										ct = ct +1;	
									}
								}								
							}
						}
}

void read_data(T16 in_buf[100][100][100], T16 *inp1, int kchd)
{
						if(kchd < 31)
						{	
						int ct1=0;
							loop_c6b1:for(int x=0;x<100;x++)
							{
								loop_c6b2:for(int y=0;y<100;y++)
								{
									loop_c6b3:for(int z=0;z<100;z++)
									{
										in_buf[x][y][z] = *(inp1 + (kchd*100) + ct1);		
										ct1 = ct1 + 1;
									}
								}								
							}
						}
}

void fun_bn2(T16 inp1[100][100][100], T16 out[100][100][100])
{	
	loop_ex1:for(int cho=0;cho<100;cho++)
	{
		loop_ex2:for(int y=0;y<100;y++)
		{
			loop_ex3: for(int z=0;z<100;z++)
			{
				out[cho][y][z] = inp1[cho][y][z] * inp1[cho][y][z];		
			}
		}		 
	}
}


void  mly9_delete(
	T16 *input_data1,
    T16 *output_data1
)
{
#pragma HLS INTERFACE m_axi depth=1024 port=input_data1 offset=slave bundle=input1
#pragma HLS INTERFACE s_axilite port=input_data1		
#pragma HLS INTERFACE m_axi depth=1024 port=output_data1 offset=slave bundle=output1
#pragma HLS INTERFACE s_axilite port=output_data1
#pragma HLS INTERFACE s_axilite port=return
	
	
    T16 dbufA_ping[100][100][100];
    T16 dbufA_pong[100][100][100]; 
    T16 outbuf_ping[100][100][100];
    T16 outbuf_pong[100][100][100];	
//#pragma HLS array_partition variable=dbufA_ping complete dim=0
//#pragma HLS array_partition variable=dbufA_pong complete dim=0
//#pragma HLS array_partition variable=outbuf_ping complete dim=0
//#pragma HLS array_partition variable=outbuf_pong complete dim=0
int kchw1 = 0;
int kchw2 = 0;
int kchr1 = 0;
int kchr2 = 0;
	
//#pragma HLS dataflow
							read_data(dbufA_ping, input_data1,0);			
																			
				loop_dep1:for (int ch = 0; ch < 32; ch++)  //1024/64=16 , here depth is covered.
				{
					if( ch % 2 == 0 )
					{						
						loop_c1:for(int x=0;x<1;x++)
						{
							fun_bn2(dbufA_ping, outbuf_ping);
						}
							loop_w1:for(int y=0;y<1;y++)
							{								
								write_off(output_data1, outbuf_pong,kchw1);
								kchw1 = kchw1 + 1;
							}	
							loop_r1:for(int y=0;y<1;y++)
							{							
								read_data(dbufA_pong, input_data1, kchr1);
								kchr1 = kchr1 +1;
							}			
					}	
					else if( ch % 2 == 1 )
					{												
						loop_c2:for(int x=0;x<1;x++)
						{					
							fun_bn2(dbufA_pong, outbuf_pong);
						}
							loop_w2:for(int y=0;y<1;y++)
							{								
								write_off(output_data1, outbuf_ping, kchw2);
								kchw2 = kchw2 + 1;
							}				
							loop_r2:for(int y=0;y<1;y++)
							{							
								read_data(dbufA_ping, input_data1, kchr2);										
								kchr2 = kchr2 + 1;
							}
					}
				}			
}



