#include<stdio.h>
#include "math.h"

void write_off(float *out1,float *out2, float *out3, float *out4, float (*out_buf)[7][7])
{	
 						   int OFFCHIP_WIDTH1=7;
							int startRow1 = 0;
							int startCol1 = 0;							
							loop_c13:for (int cho = 0; cho < 32; cho=cho+4)
							{
								loop_c14:for (int r = 0; r < 7; r++)
								{
									loop_c15:for (int c = 0; c < 7; c++)
									{
										*(out1 + (startRow1 + r) * OFFCHIP_WIDTH1 + startCol1 + c + cho*7*7) = out_buf[cho][r][c];
										*(out2 + (startRow1 + r) * OFFCHIP_WIDTH1 + startCol1 + c + (cho+1)*7*7) = out_buf[cho+1][r][c];
										*(out3 + (startRow1 + r) * OFFCHIP_WIDTH1 + startCol1 + c + (cho+2)*7*7) = out_buf[cho+2][r][c];
										*(out4 + (startRow1 + r) * OFFCHIP_WIDTH1 + startCol1 + c + (cho+3)*7*7) = out_buf[cho+3][r][c];
									}			
								}
							}												
}

void read_data(float (*in_buf)[9][9], float *inp1, float *inp2, float *inp3, float *inp4)
{
	    											int OFFCHIP_WIDTH=9;
													loop_c6: for(int ch_inp=0;ch_inp<32;ch_inp = ch_inp+4)
													{
														loop_c7:for (int i = 0; i < 9; i++)
														{
															loop_c8:for (int j = 0; j < 9; j++)
															{
																in_buf[ch_inp  ][i][j] = *(inp1 + (i * OFFCHIP_WIDTH) + j + (ch_inp    )*9*9);				
																in_buf[ch_inp+1][i][j] = *(inp2 + (i * OFFCHIP_WIDTH) + j + (ch_inp + 1)*9*9);	
																in_buf[ch_inp+2][i][j] = *(inp3 + (i * OFFCHIP_WIDTH) + j + (ch_inp + 2)*9*9);	
																in_buf[ch_inp+3][i][j] = *(inp4 + (i * OFFCHIP_WIDTH) + j + (ch_inp + 3)*9*9);	
															}
														}
													}		
}

void read_wts(float (*wt_buf)[3][3], float *inpwt1, float *inpwt2, float *inpwt3, float *inpwt4, int kch)
{
													loop_c9: for(int ch_inp=0;ch_inp<32;ch_inp = ch_inp+4)
													{			
														loop_c10:for (int i = 0; i < 3; i++)
														{
															loop_c11:for (int j = 0; j < 3; j++)
															{
																wt_buf[ch_inp  ][i][j] = *(inpwt1 + kch);												
																wt_buf[ch_inp+1][i][j] = *(inpwt2 + kch + 1);												
																wt_buf[ch_inp+2][i][j] = *(inpwt3 + kch + 2);												
																wt_buf[ch_inp+3][i][j] = *(inpwt4 + kch + 3);
																kch = kch + 8 ;																								
															}
														}		
													}		
}


void fun_dw1(float inp[9][9] , float cvw[3][3], float out[7][7], float bgammax, float bbetax, float bmeanx, float bvarx)
{
    label1:for (int j = 0; j < 7; j++) {
    	label2:for (int m = 0; m < 7; m++) {
    		float out_temp = 0;
    		label3:for (int x = 0; x < 3; x++) {
    			label4:for (int y = 0; y < 3; y++) {
                	out_temp += inp[j + x][m + y] * cvw[x][y];
                	//out_temp = inp[j + x][m + y]; // * cvw[x][y];
                }
            }
				float normalized_value = (out_temp - bmeanx) / sqrt(bvarx+1e-3);
				float scaled_value = bgammax * normalized_value + bbetax;
				if(scaled_value < 0.0)
				{
					out[j][m]= 0.0;
				}
				else if(scaled_value > 6.0)
				{
					out[j][m]= 6.0;
				}
				else
				{
					out[j][m]=scaled_value;
				}            
        }
    }
}
/*
void fun_bn1(float (*inp1)[7][7], int length, float *bgammax, float *bbetax, float *bmeanx, float *bvarx, float (*out1)[7][7])
{
	label5:for(int cho=0;cho<length;cho++){
		label6:for(int r=0;r<7;r++){
			label7:for(int c=0;c<7;c++){
				float normalized_value = (inp1[cho][r][c] - bmeanx[cho]) / sqrt(bvarx[cho]+1e-3);
				float scaled_value = bgammax[cho] * normalized_value + bbetax[cho];
				if(scaled_value < 0.0)
				{
					out1[cho][r][c]= 0.0;
				}
				else if(scaled_value > 6.0)
				{
					out1[cho][r][c]= 6.0;
				}
				else
				{
					out1[cho][r][c]=scaled_value;
				}
			}
		}
	}
}
*/
/*
void fun_pw1(float (*inp2)[7][7], int length, float (*cvw2), float (*out2)[7][7], int length0)
{
    label8: for (int r = 0; r < 7; r++) {
        label9: for (int c = 0; c < 7; c++) {
            label10: for (int cho = 0; cho < length0; cho++) {
                label11: for (int chi = 0; chi < length; chi++) {
                    out2[cho][r][c] += inp2[chi][r][c] * cvw2[cho * length + chi];
                }
            }
        }
    }
}

void fun_bn2(float (*inp1)[7][7], float (*bgammax), float (*bbetax), float (*bmeanx), float (*bvarx), float (*out)[7][7])
{
	label12:for(int cho=0;cho<64;cho++){
		float scaled_value;
		label3:for(int r=0;r<7;r++){
			label14:for(int c=0;c<7;c++){
				
					float normalized_value = (inp1[cho][r][c] - bmeanx[cho]) / sqrt(bvarx[cho]+1e-3);
					scaled_value = bgammax[cho] * normalized_value + bbetax[cho];
				
				if(scaled_value < 0.0)
				{
					out[cho][r][c]= 0.0;
				}
				else if(scaled_value > 6.0)
				{
					out[cho][r][c]= 6.0;
				}
				else
				{
					out[cho][r][c]=scaled_value;
				}
			}
		}
	}
}
*/
void  mly9_db(
    float *conv9_dw1,
    float *conv9_dw2,
    float *conv9_dw3,
    float *conv9_dw4,
    float *conv9_pw,
	float *input_data1,
	float *input_data2,
	float *input_data3,
	float *input_data4,
    float *output_data1,
    float *output_data2,
    float *output_data3,
    float *output_data4
)

{
#pragma HLS INTERFACE m_axi depth=1024 port=conv9_dw1 offset=slave bundle=conv9d1
#pragma HLS INTERFACE s_axilite port=conv9_dw1
#pragma HLS INTERFACE m_axi depth=1024 port=conv9_dw2 offset=slave bundle=conv9d2
#pragma HLS INTERFACE s_axilite port=conv9_dw2
#pragma HLS INTERFACE m_axi depth=1024 port=conv9_dw3 offset=slave bundle=conv9d3
#pragma HLS INTERFACE s_axilite port=conv9_dw3
#pragma HLS INTERFACE m_axi depth=1024 port=conv9_dw4 offset=slave bundle=conv9d4
#pragma HLS INTERFACE s_axilite port=conv9_dw4

#pragma HLS INTERFACE m_axi depth=1024 port=conv9_pw offset=slave bundle=conv9p
#pragma HLS INTERFACE s_axilite port=conv9_pw

#pragma HLS INTERFACE m_axi depth=1024 port=input_data1 offset=slave bundle=input1
#pragma HLS INTERFACE s_axilite port=input_data1
#pragma HLS INTERFACE m_axi depth=1024 port=input_data2 offset=slave bundle=input2
#pragma HLS INTERFACE s_axilite port=input_data2
#pragma HLS INTERFACE m_axi depth=1024 port=input_data3 offset=slave bundle=input3
#pragma HLS INTERFACE s_axilite port=input_data3
#pragma HLS INTERFACE m_axi depth=1024 port=input_data4 offset=slave bundle=input4
#pragma HLS INTERFACE s_axilite port=input_data4

#pragma HLS INTERFACE m_axi depth=1024 port=output_data1 offset=slave bundle=output1
#pragma HLS INTERFACE s_axilite port=output_data1
#pragma HLS INTERFACE m_axi depth=1024 port=output_data2 offset=slave bundle=output2
#pragma HLS INTERFACE s_axilite port=output_data2
#pragma HLS INTERFACE m_axi depth=1024 port=output_data3 offset=slave bundle=output3
#pragma HLS INTERFACE s_axilite port=output_data3
#pragma HLS INTERFACE m_axi depth=1024 port=output_data4 offset=slave bundle=output4
#pragma HLS INTERFACE s_axilite port=output_data4
#pragma HLS INTERFACE s_axilite port=return

#include "D:\\mobilenet\\mobly9_act\\conv9d_1.txt"
#include "D:\\mobilenet\\mobly9_act\\conv9d_2.txt"
#include "D:\\mobilenet\\mobly9_act\\conv9d_3.txt"
#include "D:\\mobilenet\\mobly9_act\\conv9d_4.txt"

#pragma HLS array_partition variable=gamma complete dim=0
#pragma HLS array_partition variable=beta complete dim=0
#pragma HLS array_partition variable=batch_mean complete dim=0
#pragma HLS array_partition variable=batch_variance complete dim=0

#include "D:\\mobilenet\\mobly9_act\\conv9p_1.txt"
#include "D:\\mobilenet\\mobly9_act\\conv9p_2.txt"
#include "D:\\mobilenet\\mobly9_act\\conv9p_3.txt"
#include "D:\\mobilenet\\mobly9_act\\conv9p_4.txt"

#pragma HLS array_partition variable=gamma1 complete dim=0
#pragma HLS array_partition variable=beta1 complete dim=0
#pragma HLS array_partition variable=batch_mean1 complete dim=0
#pragma HLS array_partition variable=batch_variance1 complete dim=0

    float dbufA_ping[32][9][9];
    float dbufA_pong[32][9][9];
	#pragma HLS array_partition variable=dbufA_ping cyclic factor=32 dim=1
	#pragma HLS array_partition variable=dbufA_pong cyclic factor=32 dim=1
	//#pragma HLS array_partition variable=dbufA_ping complete dim=0
	//#pragma HLS array_partition variable=dbufA_pong complete dim=0
    float wbufA_ping[32][3][3];
    float wbufA_pong[32][3][3];
	#pragma HLS array_partition variable=wbufA_ping cyclic factor=32 dim=1
	#pragma HLS array_partition variable=wbufA_pong cyclic factor=32 dim=1    
	//#pragma HLS array_partition variable=wbufA_ping complete dim=0
	//#pragma HLS array_partition variable=wbufA_pong complete dim=0
    float outbuf_ping[32][7][7];
    float outbuf_pong[32][7][7];
	#pragma HLS array_partition variable=outbuf_ping cyclic factor=32 dim=1
	#pragma HLS array_partition variable=outbuf_pong cyclic factor=32 dim=1    
	//#pragma HLS array_partition variable=outbuf_ping complete dim=0
	//#pragma HLS array_partition variable=outbuf_pong complete dim=0

     //float pw_w_buf1[64][32];
	//#pragma HLS array_partition variable=pw_w_buf1 cyclic factor=32 dim=2
	//#pragma HLS array_partition variable=pw_w_buf1 cyclic factor=16 dim=1
    //static float pw_w_buf2[512][1024];
	//#pragma HLS array_partition variable=pw_w_buf2 cyclic factor=32 dim=2
	//#pragma HLS array_partition variable=pw_w_buf2 cyclic factor=16 dim=1
	 //float pw_out_buf1[64][7][7];
	 //float pw_out_buft[64][7][7];
	//#pragma HLS array_partition variable=pw_out_buf1 cyclic factor=16 dim=1
    //static float pw_out_buf2[512][7][7];
	//#pragma HLS array_partition variable=pw_out_buf2 cyclic factor=16 dim=1
	 //float out_bn2_buf1[64][7][7];
	//#pragma HLS array_partition variable=out_bn2_buf1 cyclic factor=8 dim=1

    int OFFCHIP_WIDTH=9;
    int OFFCHIP_WIDTH1=7;
    int kchinx1=0;
    int kchiny1=0;
    int kchin2=0;
    int ch_inp = 0;
    int k=0;
    	

							read_data(dbufA_ping, input_data1, input_data2, input_data3, input_data4);
							read_wts(wbufA_ping, conv9_dw1, conv9_dw2, conv9_dw3, conv9_dw4, kchiny1);	
							kchiny1 = kchiny1+4 ;									
															
										

		
		
		//#pragma HLS dataflow
		//#pragma HLS dataflow
		loop_c1:for (int ch = 0; ch < 32; ch++)  //1024
		{
			if( ch % 2 == 0 )
			{			
    			loop_c2:for(int tileIndex=0;tileIndex<1;tileIndex++)  // only 1 as size of each image is 30x30 only
    			{ 							
					int startRow = (tileIndex / 1) * (9 - 2);
					int startCol = (tileIndex % 1) * (9 - 2);										
					fun_dw1(dbufA_ping[0],wbufA_ping[0],outbuf_ping[0], gamma[ch+0], beta[ch+0], batch_mean[ch+0], batch_variance[ch+0]);
					fun_dw1(dbufA_ping[1],wbufA_ping[1],outbuf_ping[1], gamma[ch+1], beta[ch+1], batch_mean[ch+1], batch_variance[ch+1]);
					fun_dw1(dbufA_ping[2],wbufA_ping[2],outbuf_ping[2], gamma[ch+2], beta[ch+2], batch_mean[ch+2], batch_variance[ch+2]);
					fun_dw1(dbufA_ping[3],wbufA_ping[3],outbuf_ping[3], gamma[ch+3], beta[ch+3], batch_mean[ch+3], batch_variance[ch+3]);
					fun_dw1(dbufA_ping[4],wbufA_ping[4],outbuf_ping[4], gamma[ch+4], beta[ch+4], batch_mean[ch+4], batch_variance[ch+4]);
					fun_dw1(dbufA_ping[5],wbufA_ping[5],outbuf_ping[5], gamma[ch+5], beta[ch+5], batch_mean[ch+5], batch_variance[ch+5]);
					fun_dw1(dbufA_ping[6],wbufA_ping[6],outbuf_ping[6], gamma[ch+6], beta[ch+6], batch_mean[ch+6], batch_variance[ch+6]);
					fun_dw1(dbufA_ping[7],wbufA_ping[7],outbuf_ping[7], gamma[ch+7], beta[ch+7], batch_mean[ch+7], batch_variance[ch+7]);
					fun_dw1(dbufA_ping[8],wbufA_ping[8],outbuf_ping[8], gamma[ch+8], beta[ch+8], batch_mean[ch+8], batch_variance[ch+8]);
					fun_dw1(dbufA_ping[9],wbufA_ping[9],outbuf_ping[9], gamma[ch+9], beta[ch+9], batch_mean[ch+9], batch_variance[ch+9]);
					fun_dw1(dbufA_ping[10],wbufA_ping[10],outbuf_ping[10], gamma[ch+10], beta[ch+10], batch_mean[ch+10], batch_variance[ch+10]);
					fun_dw1(dbufA_ping[11],wbufA_ping[11],outbuf_ping[11], gamma[ch+11], beta[ch+11], batch_mean[ch+11], batch_variance[ch+11]);
					fun_dw1(dbufA_ping[12],wbufA_ping[12],outbuf_ping[12], gamma[ch+12], beta[ch+12], batch_mean[ch+12], batch_variance[ch+12]);
					fun_dw1(dbufA_ping[13],wbufA_ping[13],outbuf_ping[13], gamma[ch+13], beta[ch+13], batch_mean[ch+13], batch_variance[ch+13]);
					fun_dw1(dbufA_ping[14],wbufA_ping[14],outbuf_ping[14], gamma[ch+14], beta[ch+14], batch_mean[ch+14], batch_variance[ch+14]);
					fun_dw1(dbufA_ping[15],wbufA_ping[15],outbuf_ping[15], gamma[ch+15], beta[ch+15], batch_mean[ch+15], batch_variance[ch+15]);
					fun_dw1(dbufA_ping[16],wbufA_ping[16],outbuf_ping[16], gamma[ch+16], beta[ch+16], batch_mean[ch+16], batch_variance[ch+16]);
					fun_dw1(dbufA_ping[17],wbufA_ping[17],outbuf_ping[17], gamma[ch+17], beta[ch+17], batch_mean[ch+17], batch_variance[ch+17]);
					fun_dw1(dbufA_ping[18],wbufA_ping[18],outbuf_ping[18], gamma[ch+18], beta[ch+18], batch_mean[ch+18], batch_variance[ch+18]);
					fun_dw1(dbufA_ping[19],wbufA_ping[19],outbuf_ping[19], gamma[ch+19], beta[ch+19], batch_mean[ch+19], batch_variance[ch+19]);
					fun_dw1(dbufA_ping[20],wbufA_ping[20],outbuf_ping[20], gamma[ch+20], beta[ch+20], batch_mean[ch+20], batch_variance[ch+20]);
					fun_dw1(dbufA_ping[21],wbufA_ping[21],outbuf_ping[21], gamma[ch+21], beta[ch+21], batch_mean[ch+21], batch_variance[ch+21]);
					fun_dw1(dbufA_ping[22],wbufA_ping[22],outbuf_ping[22], gamma[ch+22], beta[ch+22], batch_mean[ch+22], batch_variance[ch+22]);
					fun_dw1(dbufA_ping[23],wbufA_ping[23],outbuf_ping[23], gamma[ch+23], beta[ch+23], batch_mean[ch+23], batch_variance[ch+23]);
					fun_dw1(dbufA_ping[24],wbufA_ping[24],outbuf_ping[24], gamma[ch+24], beta[ch+24], batch_mean[ch+24], batch_variance[ch+24]);
					fun_dw1(dbufA_ping[25],wbufA_ping[25],outbuf_ping[25], gamma[ch+25], beta[ch+25], batch_mean[ch+25], batch_variance[ch+25]);
					fun_dw1(dbufA_ping[26],wbufA_ping[26],outbuf_ping[26], gamma[ch+26], beta[ch+26], batch_mean[ch+26], batch_variance[ch+26]);
					fun_dw1(dbufA_ping[27],wbufA_ping[27],outbuf_ping[27], gamma[ch+27], beta[ch+27], batch_mean[ch+27], batch_variance[ch+27]);
					fun_dw1(dbufA_ping[28],wbufA_ping[28],outbuf_ping[28], gamma[ch+28], beta[ch+28], batch_mean[ch+28], batch_variance[ch+28]);
					fun_dw1(dbufA_ping[29],wbufA_ping[29],outbuf_ping[29], gamma[ch+29], beta[ch+29], batch_mean[ch+29], batch_variance[ch+29]);
					fun_dw1(dbufA_ping[30],wbufA_ping[30],outbuf_ping[30], gamma[ch+30], beta[ch+30], batch_mean[ch+30], batch_variance[ch+30]);
					fun_dw1(dbufA_ping[31],wbufA_ping[31],outbuf_ping[31], gamma[ch+31], beta[ch+31], batch_mean[ch+31], batch_variance[ch+31]);		
				}
					loop_d1:for(int x=0;x<1;x++)
					{					
						if(ch > 0)
						{		
							write_off(output_data1, output_data2, output_data3, output_data4, outbuf_pong);																		
						}
					}
					loop_e1:for(int y=0;y<1;y++)
					{
						if(ch < 31)
						{		
							read_data(dbufA_pong, input_data1, input_data2, input_data3, input_data4);
							read_wts(wbufA_pong, conv9_dw1, conv9_dw2, conv9_dw3, conv9_dw4, kchinx1);
							kchinx1 = kchinx1 + 8;
						}
					}
			}
			else if( ch % 2 == 1 )
			{
				//#pragma HLS dataflow
				//#pragma HLS parallel
    			loop_c12:for(int tileIndex=0;tileIndex<1;tileIndex++)  // only 1 as size of each image is 30x30 only
    			{ 															   
    				//#pragma HLS PIPELINE
					int startRow = (tileIndex / 1) * (9 - 2);
					int startCol = (tileIndex % 1) * (9 - 2);					
					fun_dw1(dbufA_pong[0],wbufA_pong[0],outbuf_pong[0], gamma[ch+0], beta[ch+0], batch_mean[ch+0], batch_variance[ch+0]);
					fun_dw1(dbufA_pong[1],wbufA_pong[1],outbuf_pong[1], gamma[ch+1], beta[ch+1], batch_mean[ch+1], batch_variance[ch+1]);
					fun_dw1(dbufA_pong[2],wbufA_pong[2],outbuf_pong[2], gamma[ch+2], beta[ch+2], batch_mean[ch+2], batch_variance[ch+2]);
					fun_dw1(dbufA_pong[3],wbufA_pong[3],outbuf_pong[3], gamma[ch+3], beta[ch+3], batch_mean[ch+3], batch_variance[ch+3]);
					fun_dw1(dbufA_pong[4],wbufA_pong[4],outbuf_pong[4], gamma[ch+4], beta[ch+4], batch_mean[ch+4], batch_variance[ch+4]);
					fun_dw1(dbufA_pong[5],wbufA_pong[5],outbuf_pong[5], gamma[ch+5], beta[ch+5], batch_mean[ch+5], batch_variance[ch+5]);
					fun_dw1(dbufA_pong[6],wbufA_pong[6],outbuf_pong[6], gamma[ch+6], beta[ch+6], batch_mean[ch+6], batch_variance[ch+6]);
					fun_dw1(dbufA_pong[7],wbufA_pong[7],outbuf_pong[7], gamma[ch+7], beta[ch+7], batch_mean[ch+7], batch_variance[ch+7]);
					fun_dw1(dbufA_pong[8],wbufA_pong[8],outbuf_pong[8], gamma[ch+8], beta[ch+8], batch_mean[ch+8], batch_variance[ch+8]);
					fun_dw1(dbufA_pong[9],wbufA_pong[9],outbuf_pong[9], gamma[ch+9], beta[ch+9], batch_mean[ch+9], batch_variance[ch+9]);
					fun_dw1(dbufA_pong[10],wbufA_pong[10],outbuf_pong[10], gamma[ch+10], beta[ch+10], batch_mean[ch+10], batch_variance[ch+10]);
					fun_dw1(dbufA_pong[11],wbufA_pong[11],outbuf_pong[11], gamma[ch+11], beta[ch+11], batch_mean[ch+11], batch_variance[ch+11]);
					fun_dw1(dbufA_pong[12],wbufA_pong[12],outbuf_pong[12], gamma[ch+12], beta[ch+12], batch_mean[ch+12], batch_variance[ch+12]);
					fun_dw1(dbufA_pong[13],wbufA_pong[13],outbuf_pong[13], gamma[ch+13], beta[ch+13], batch_mean[ch+13], batch_variance[ch+13]);
					fun_dw1(dbufA_pong[14],wbufA_pong[14],outbuf_pong[14], gamma[ch+14], beta[ch+14], batch_mean[ch+14], batch_variance[ch+14]);
					fun_dw1(dbufA_pong[15],wbufA_pong[15],outbuf_pong[15], gamma[ch+15], beta[ch+15], batch_mean[ch+15], batch_variance[ch+15]);
					fun_dw1(dbufA_pong[16],wbufA_pong[16],outbuf_pong[16], gamma[ch+16], beta[ch+16], batch_mean[ch+16], batch_variance[ch+16]);
					fun_dw1(dbufA_pong[17],wbufA_pong[17],outbuf_pong[17], gamma[ch+17], beta[ch+17], batch_mean[ch+17], batch_variance[ch+17]);
					fun_dw1(dbufA_pong[18],wbufA_pong[18],outbuf_pong[18], gamma[ch+18], beta[ch+18], batch_mean[ch+18], batch_variance[ch+18]);
					fun_dw1(dbufA_pong[19],wbufA_pong[19],outbuf_pong[19], gamma[ch+19], beta[ch+19], batch_mean[ch+19], batch_variance[ch+19]);
					fun_dw1(dbufA_pong[20],wbufA_pong[20],outbuf_pong[20], gamma[ch+20], beta[ch+20], batch_mean[ch+20], batch_variance[ch+20]);
					fun_dw1(dbufA_pong[21],wbufA_pong[21],outbuf_pong[21], gamma[ch+21], beta[ch+21], batch_mean[ch+21], batch_variance[ch+21]);
					fun_dw1(dbufA_pong[22],wbufA_pong[22],outbuf_pong[22], gamma[ch+22], beta[ch+22], batch_mean[ch+22], batch_variance[ch+22]);
					fun_dw1(dbufA_pong[23],wbufA_pong[23],outbuf_pong[23], gamma[ch+23], beta[ch+23], batch_mean[ch+23], batch_variance[ch+23]);
					fun_dw1(dbufA_pong[24],wbufA_pong[24],outbuf_pong[24], gamma[ch+24], beta[ch+24], batch_mean[ch+24], batch_variance[ch+24]);
					fun_dw1(dbufA_pong[25],wbufA_pong[25],outbuf_pong[25], gamma[ch+25], beta[ch+25], batch_mean[ch+25], batch_variance[ch+25]);
					fun_dw1(dbufA_pong[26],wbufA_pong[26],outbuf_pong[26], gamma[ch+26], beta[ch+26], batch_mean[ch+26], batch_variance[ch+26]);
					fun_dw1(dbufA_pong[27],wbufA_pong[27],outbuf_pong[27], gamma[ch+27], beta[ch+27], batch_mean[ch+27], batch_variance[ch+27]);
					fun_dw1(dbufA_pong[28],wbufA_pong[28],outbuf_pong[28], gamma[ch+28], beta[ch+28], batch_mean[ch+28], batch_variance[ch+28]);
					fun_dw1(dbufA_pong[29],wbufA_pong[29],outbuf_pong[29], gamma[ch+29], beta[ch+29], batch_mean[ch+29], batch_variance[ch+29]);
					fun_dw1(dbufA_pong[30],wbufA_pong[30],outbuf_pong[30], gamma[ch+30], beta[ch+30], batch_mean[ch+30], batch_variance[ch+30]);
					fun_dw1(dbufA_pong[31],wbufA_pong[31],outbuf_pong[31], gamma[ch+31], beta[ch+31], batch_mean[ch+31], batch_variance[ch+31]);							
					//fun_bn1(&dbufA_pong[0],32, &gamma[ch], &beta[ch], &batch_mean[ch], &batch_variance[ch], &dw_bn_out[0]);		
				}
					loop_d12:for(int x=0;x<1;x++)
					{					
						if(ch > 0)
						{		
							write_off(output_data1, output_data2, output_data3, output_data4, outbuf_ping);																		
						}
					}
					loop_e12:for(int y=0;y<1;y++)
					{					
						if(ch < 31)
						{		
							read_data(dbufA_ping, input_data1, input_data2, input_data3, input_data4);
							read_wts(wbufA_ping, conv9_dw1, conv9_dw2, conv9_dw3, conv9_dw4, kchiny1);
							kchiny1 = kchiny1 + 8;
						}	
					}
			}									
																										
	
									
    }
}

