#include<stdio.h>
#include "math.h"

void fun_dw1(float inp[9][9] , float cvw[3][3], float out[7][7])
{
    label1:for (int j = 0; j < 7; j++) {
    	label2:for (int m = 0; m < 7; m++) {
    		label3:for (int x = 0; x < 3; x++) {
    			label4:for (int y = 0; y < 3; y++) {
                	out[j][m] += inp[j + x][m + y] * cvw[x][y];
                }
            }
        }
    }
}


void fun_bn1(float inp1[32][7][7], float bgammax[32], float bbetax[32], float bmeanx[32], float bvarx[32], float out1[32][7][7])
{
	label5:for(int cho=0;cho<32;cho++){
		label6:for(int r=0;r<7;r++){
			label7:for(int c=0;c<7;c++){
				float normalized_value = (inp1[cho][r][c] - bmeanx[cho]) / sqrt(bvarx[cho]+1e-3);
				float scaled_value = bgammax[cho] * normalized_value + bbetax[cho];
				if(scaled_value < 0.0)
				{
					out1[cho][r][c]= 0.0;
				}
				else if(scaled_value > 6.0)
				{
					out1[cho][r][c]= 6.0;
				}
				else
				{
					out1[cho][r][c]=scaled_value;
				}
			}
		}
	}
}

void fun_pw1(float inp2[32][7][7], float cvw2[32][32], float out2[32][7][7])
{
	label8:for (int r = 0; r < 7; r++) {
		label9:for (int c = 0; c < 7; c++) {
			label10:for (int cho = 0; cho < 32; cho++) {
				label11:for (int chi = 0; chi < 32; chi++) {
                    out2[cho][r][c] += inp2[chi][r][c] * cvw2[cho][chi];
                }
            }
        }
    }
}

void fun_bn2(float inp1[32][7][7], float inp2[32][7][7], float bgammax[64], float bbetax[64], float bmeanx[64], float bvarx[64], float out[64][7][7])
{

	label12:for(int cho=0;cho<64;cho++){
		float scaled_value;
		label3:for(int r=0;r<7;r++){
			label14:for(int c=0;c<7;c++){
				if(cho < 32){
					float normalized_value = (inp1[cho][r][c] - bmeanx[cho]) / sqrt(bvarx[cho]+1e-3);
					scaled_value = bgammax[cho] * normalized_value + bbetax[cho];
				}
				else{
					float normalized_value = (inp2[cho-32][r][c] - bmeanx[cho]) / sqrt(bvarx[cho]+1e-3);
					scaled_value = bgammax[cho] * normalized_value + bbetax[cho];
				}
				if(scaled_value < 0.0)
				{
					out[cho][r][c]= 0.0;
				}
				else if(scaled_value > 6.0)
				{
					out[cho][r][c]= 6.0;
				}
				else
				{
					out[cho][r][c]=scaled_value;
				}
			}
		}
	}
}



void  mobly1_float(
    float *conv1_dw,
    float *conv1_pw,
	float *input_data,
    float *output_data
)

{



#pragma HLS INTERFACE m_axi depth=32 port=conv1_dw offset=slave bundle=conv1d
#pragma HLS INTERFACE s_axilite port=conv1_dw

#pragma HLS INTERFACE m_axi depth=64 port=conv1_pw offset=slave bundle=conv1p
#pragma HLS INTERFACE s_axilite port=conv1_pw

#pragma HLS INTERFACE m_axi depth=32 port=input_data offset=slave bundle=input
#pragma HLS INTERFACE s_axilite port=input_data

#pragma HLS INTERFACE m_axi depth=64 port=output_data offset=slave bundle=output
#pragma HLS INTERFACE s_axilite port=output_data
#pragma HLS INTERFACE s_axilite port=return

#include "D:\Term_Paper\conv1d_1.txt"
#include "D:\Term_Paper\conv1d_2.txt"
#include "D:\Term_Paper\conv1d_3.txt"
#include "D:\Term_Paper\conv1d_4.txt"

#include "D:\Term_Paper\conv1p_1.txt"
#include "D:\Term_Paper\conv1p_2.txt"
#include "D:\Term_Paper\conv1p_3.txt"
#include "D:\Term_Paper\conv1p_4.txt"

#pragma HLS array_partition variable=gamma complete dim=0
#pragma HLS array_partition variable=beta complete dim=0
#pragma HLS array_partition variable=batch_mean complete dim=0
#pragma HLS array_partition variable=batch_variance complete dim=0

    float d1planar1x1[16][9][9];

    float xbufferw1[3][3] , xbufferw2[3][3] , xbufferw3[3][3] , xbufferw4[3][3] , xbufferw5[3][3] ,
		  xbufferw6[3][3] , xbufferw7[3][3] , xbufferw8[3][3] , xbufferw9[3][3] , xbufferw10[3][3] ,
		  xbufferw11[3][3] , xbufferw12[3][3] , xbufferw13[3][3] , xbufferw14[3][3] , xbufferw15[3][3] ,
		  xbufferw16[3][3] , xbufferw17[3][3] , xbufferw18[3][3] , xbufferw19[3][3] , xbufferw20[3][3] ,
		  xbufferw21[3][3] , xbufferw22[3][3] , xbufferw23[3][3] , xbufferw24[3][3] , xbufferw25[3][3] ,
		  xbufferw26[3][3] , xbufferw27[3][3] , xbufferw28[3][3] , xbufferw29[3][3] , xbufferw30[3][3] ,
		  xbufferw31[3][3] , xbufferw32[3][3] ;
    
    float outbuf[16][7][7];
	//#pragma HLS array_partition variable=outbuf cyclic factor=32 dim=1
/*
    float out_bn_buf[32][7][7];
    //#pragma HLS array_partition variable=out_bn_buf cyclic factor=32 dim=1

    float pw_w_buf1[32][32];

    float pw_w_buf2[32][32];

    static float out_pw_buf1[32][7][7];

    static float out_pw_buf2[32][7][7];
    
    static float out_b1[64][7][7];

    label15:for(int dep=0;dep<32;dep++){
    	label16:for(int r=0;r<7;r++){
    		label7:for(int c=0;c<7;c++){
    			out_pw_buf1[dep][r][c]=0.0;
    			out_pw_buf2[dep][r][c]=0.0;
			}
		}
	}
*/
    int OFFCHIP_WIDTH=9;
    int OFFCHIP_WIDTH1=112;

    int kchin1=0;
    int kchin2=0;
    int chwp = 0;

    int value1 = 1*32*9;


    label18:for(int tileIndex=0;tileIndex<256;tileIndex++)  // only 1 as size of each image is 30x30 only
     {
		chwp = 0;

			int startRow = (tileIndex / 16) * (9 - 2);
			int startCol = (tileIndex % 16) * (9 - 2);
			int k=0;

			label19:for (int ch = 0; ch < 32; ch++)
			{
				label20:for (int i = 0; i < 9; i++)
				{
					label21:for (int j = 0; j < 9; j++)
					{
						d1planar1x1[ch][i][j] = *(input_data + (startRow + i) * OFFCHIP_WIDTH + startCol + j + i*(112-9) + ch*112*112);
					}
				}
			}


			label22:for (int ch = 0; ch < 32; ch++)
					{
						label23:for (int i = 0; i < 3; i++)
						{
							label24:for (int j = 0; j < 3; j++)
							{
								xbufferw1[ch][i][j] = *(conv1_dw+ kchin1);
								kchin1++;
							}
						}
					}

			kchin1 = 0;
			label22:for (int i = 0; i < 3; i++)
			{
				label23:for (int j = 0; j < 3; j++)
				{
					xbufferw1[i][j] = *(conv1_dw+ kchin1 );
					xbufferw2[i][j] = *(conv1_dw+ kchin1 + 1*9);
					xbufferw3[i][j] = *(conv1_dw+ kchin1 + 2*9);
					xbufferw4[i][j] = *(conv1_dw+ kchin1 + 3*9);
					xbufferw5[i][j] = *(conv1_dw+ kchin1 + 4*9);
					xbufferw6[i][j] = *(conv1_dw+ kchin1 + 5*9);
					xbufferw7[i][j] = *(conv1_dw+ kchin1 + 6*9);
					xbufferw8[i][j] = *(conv1_dw+ kchin1 + 7*9);
					xbufferw9[i][j] = *(conv1_dw+ kchin1 + 8*9);
					xbufferw10[i][j] = *(conv1_dw+ kchin1 + 9*9);
					xbufferw11[i][j] = *(conv1_dw+ kchin1 + 10*9);
					xbufferw12[i][j] = *(conv1_dw+ kchin1 + 11*9);
					xbufferw13[i][j] = *(conv1_dw+ kchin1 + 12*9);
					xbufferw14[i][j] = *(conv1_dw+ kchin1 + 13*9);
					xbufferw15[i][j] = *(conv1_dw+ kchin1 + 14*9);
					xbufferw16[i][j] = *(conv1_dw+ kchin1 + 15*9);
					xbufferw17[i][j] = *(conv1_dw+ kchin1 + 16*9);
					xbufferw18[i][j] = *(conv1_dw+ kchin1 + 17*9);
					xbufferw19[i][j] = *(conv1_dw+ kchin1 + 18*9);
					xbufferw20[i][j] = *(conv1_dw+ kchin1 + 19*9);
					xbufferw21[i][j] = *(conv1_dw+ kchin1 + 20*9);
					xbufferw22[i][j] = *(conv1_dw+ kchin1 + 21*9);
					xbufferw23[i][j] = *(conv1_dw+ kchin1 + 22*9);
					xbufferw24[i][j] = *(conv1_dw+ kchin1 + 23*9);
					xbufferw25[i][j] = *(conv1_dw+ kchin1 + 24*9);
					xbufferw26[i][j] = *(conv1_dw+ kchin1 + 25*9);
					xbufferw27[i][j] = *(conv1_dw+ kchin1 + 26*9);
					xbufferw28[i][j] = *(conv1_dw+ kchin1 + 27*9);
					xbufferw29[i][j] = *(conv1_dw+ kchin1 + 28*9);
					xbufferw30[i][j] = *(conv1_dw+ kchin1 + 29*9);
					xbufferw31[i][j] = *(conv1_dw+ kchin1 + 30*9);
					xbufferw32[i][j] = *(conv1_dw+ kchin1 + 31*9);
					kchin1++;
				}
			}

			fun_dw1( d1planar1x1 , xbufferw1, outbuf[0]);
			fun_dw1( d2planar1x1 , xbufferw2, outbuf[1]);
			fun_dw1( d3planar1x1 , xbufferw3, outbuf[2]);
			fun_dw1( d4planar1x1 , xbufferw4, outbuf[3]);
			fun_dw1( d5planar1x1 , xbufferw5, outbuf[4]);
			fun_dw1( d6planar1x1 , xbufferw6, outbuf[5]);
			fun_dw1( d7planar1x1 , xbufferw7, outbuf[6]);
			fun_dw1( d8planar1x1 , xbufferw8, outbuf[7]);
			fun_dw1( d9planar1x1 , xbufferw9, outbuf[8]);
			fun_dw1( d10planar1x1 , xbufferw10, outbuf[9]);
			fun_dw1( d11planar1x1 , xbufferw11, outbuf[10]);
			fun_dw1( d12planar1x1 , xbufferw12, outbuf[11]);
			fun_dw1( d13planar1x1 , xbufferw13, outbuf[12]);
			fun_dw1( d14planar1x1 , xbufferw14, outbuf[13]);
			fun_dw1( d15planar1x1 , xbufferw15, outbuf[14]);
			fun_dw1( d16planar1x1 , xbufferw16, outbuf[15]);
			fun_dw1( d17planar1x1 , xbufferw17, outbuf[16]);
			fun_dw1( d18planar1x1 , xbufferw18, outbuf[17]);
			fun_dw1( d19planar1x1 , xbufferw19, outbuf[18]);
			fun_dw1( d20planar1x1 , xbufferw20, outbuf[19]);
			fun_dw1( d21planar1x1 , xbufferw21, outbuf[20]);
			fun_dw1( d22planar1x1 , xbufferw22, outbuf[21]);
			fun_dw1( d23planar1x1 , xbufferw23, outbuf[22]);
			fun_dw1( d24planar1x1 , xbufferw24, outbuf[23]);
			fun_dw1( d25planar1x1 , xbufferw25, outbuf[24]);
			fun_dw1( d26planar1x1 , xbufferw26, outbuf[25]);
			fun_dw1( d27planar1x1 , xbufferw27, outbuf[26]);
			fun_dw1( d28planar1x1 , xbufferw28, outbuf[27]);
			fun_dw1( d29planar1x1 , xbufferw29, outbuf[28]);
			fun_dw1( d30planar1x1 , xbufferw30, outbuf[29]);
			fun_dw1( d31planar1x1 , xbufferw31, outbuf[30]);
			fun_dw1( d32planar1x1 , xbufferw32, outbuf[31]);
			/*
				fun_bn1(outbuf, gamma, beta, batch_mean, batch_variance, out_bn_buf);

				kchin2=0;
				label22:for (int i = 0; i < 32; i++)
				{
					label23:for (int j = 0; j < 32; j++)
					{
						pw_w_buf1[i][j] = *(conv1_pw+ kchin2 );
						kchin2++;
					}
				}

				int kchin3=1024;
				label24:for (int i = 0; i < 32; i++)
				{
					label25:for (int j = 0; j < 32; j++)
					{
						pw_w_buf2[i][j] = *(conv1_pw+ kchin3 );
						kchin3++;
					}
				}

				fun_pw1( out_bn_buf , pw_w_buf1, out_pw_buf1);
				fun_pw1( out_bn_buf , pw_w_buf2, out_pw_buf2);

				fun_bn2(out_pw_buf1, out_pw_buf2, gamma1, beta1, batch_mean1, batch_variance1, out_b1);

				int startRow1 = (tileIndex / 16) * 7;
				int startCol1 = (tileIndex % 16) * 7;

				label26:for (int cho = 0; cho < 64; cho++) {
					label27:for (int r = 0; r < 7; r++) {
						label28:for (int c = 0; c < 7; c++) {
				        	*(output_data + (startRow1 + r) * OFFCHIP_WIDTH1 + startCol1 + c + cho*112*112 ) = out_b1[cho][r][c];
				        	//printf(" %d \t",(output_data + (startRow1 + r) * OFFCHIP_WIDTH1 + startCol1 + c + cho*112*112 ));
				        }
					}
				}
			*/
     }
}
